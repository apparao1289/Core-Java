package com.hubzu.ttd.test;

import org.mockito.Mockito;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hubzu.ttd.bid.BidConstants;
import com.hubzu.ttd.bid.BidDaoImpl;
import com.hubzu.ttd.bid.BidDto;
import com.hubzu.ttd.bid.BidService;
import com.hubzu.ttd.bid.BidServiceImpl;
import com.hubzu.ttd.user.HubzuServiceException;

public class PlaceBidServiceTest {
	
	public BidService bidService;
	public BidDaoImpl bidDaoImpl;
	
	@BeforeClass
	public void init(){
		bidDaoImpl = Mockito.mock(BidDaoImpl.class);
		bidService = new BidServiceImpl(bidDaoImpl);
	}
	
	@Test
	public void testPlaceBidBidServiceNull(){
		Assert.assertNotNull(bidService);
	}
	
	@Test
	public void testPlaceBidAmountBidDtoNull() throws HubzuServiceException{
		BidDto bidDto = null;
		Assert.assertEquals(bidService.placeBid(bidDto), false);
	}
	
	@Test
	public void testBidDtoNotNull() throws HubzuServiceException{
		BidDto bidDto = new BidDto();
		Assert.assertEquals(bidService.placeBid(bidDto), false);
	}
	
	@Test(expectedExceptions = HubzuServiceException.class)
	public void testPlaceBidAmountZero() throws HubzuServiceException{
		BidDto bidDto = new BidDto();
		bidDto.setBidAmount(0);
		Assert.assertEquals(bidService.placeBid(bidDto), false);
	}
	
	@Test
	public void testPlaceBidGreaterThanCurrentHighBid() throws HubzuServiceException{
		BidDto bidDto = new BidDto();
		bidDto.setBidAmount(10000);
		Assert.assertEquals(bidService.placeBid(bidDto), false);
	}
	
	@Test(expectedExceptions = HubzuServiceException.class)
	public void testPlaceBidGtThanCurrentHighBid() throws HubzuServiceException{
		BidDto bidDto = new BidDto();
		bidDto.setBidAmount(10000);
		Mockito.when(bidDaoImpl.getCurrentHighestBidOnListing()).thenReturn(40000);
		Assert.assertEquals(bidService.placeBid(bidDto), false);
	}
	
	@Test
	public void testPlaceBidValidateBuyerDetails() throws HubzuServiceException{
		BidDto bidDto = new BidDto();
		bidDto.setBidAmount(50000);
		bidDto.setBuyerEmailId("test@gmail.com");
		bidDto.setFirstName("Rama");
		bidDto.setLastName("Rao");
		bidDto.setBidType("Flat Bid");
		Mockito.when(bidDaoImpl.getCurrentHighestBidOnListing()).thenReturn(40000);
		Assert.assertEquals(bidService.placeBid(bidDto), false);
	}
	
	@Test
	public void testSavePlaceBids() throws HubzuServiceException{
		BidDto bidDto = new BidDto();
		bidDto.setBidAmount(50000);
		bidDto.setBuyerEmailId("test@gmail.com");
		bidDto.setFirstName("Rama");
		bidDto.setLastName("Rao");
		bidDto.setBidType("Flat Bid");
		Mockito.when(bidDaoImpl.verifyBuyerDetails(bidDto)).thenReturn(true);
		Mockito.when(bidDaoImpl.getCurrentHighestBidOnListing()).thenReturn(40000);
		Mockito.when(bidDaoImpl.savePlaceBidDetails(bidDto)).thenReturn(true);
		Assert.assertEquals(bidService.placeBid(bidDto), true);
		Mockito.verify(bidDaoImpl).savePlaceBidDetails(bidDto); 
	}
	
	@Test
	public void testOwnItNowBid() throws HubzuServiceException{
		BidDto bidDto = new BidDto();
		bidDto.setBidAmount(60000);
		bidDto.setBuyerEmailId("test12@gmail.com");
		bidDto.setFirstName("Rama123");
		bidDto.setLastName("Rao1");
		bidDto.setBidType("Own It Now");
		Mockito.when(bidDaoImpl.verifyBuyerDetails(bidDto)).thenReturn(true);
		Mockito.when(bidDaoImpl.getCurrentHighestBidOnListing()).thenReturn(40000);
		Mockito.when(bidDaoImpl.savePlaceBidDetails(bidDto)).thenReturn(true);
		Assert.assertEquals(bidService.placeBid(bidDto), true);
		Mockito.verify(bidDaoImpl).savePlaceBidDetails(bidDto); 
		Assert.assertEquals(BidConstants.SPND,bidDto.getPropertyStatus());
	}
	
	@Test
	public void testPlaceBidCompleteFlow() throws HubzuServiceException{
		BidDto bidDto = new BidDto();
		bidDto.setBidAmount(70000);
		bidDto.setBuyerEmailId("rao@gmail.com");
		bidDto.setFirstName("Apparao");
		bidDto.setLastName("G");
		bidDto.setBidType("Flat Bid");
		Mockito.when(bidDaoImpl.verifyBuyerDetails(bidDto)).thenReturn(true);
		Mockito.when(bidDaoImpl.getCurrentHighestBidOnListing()).thenReturn(40000);
		Mockito.when(bidDaoImpl.savePlaceBidDetails(bidDto)).thenReturn(true);
		Assert.assertEquals(bidService.placeBid(bidDto), true);
		Mockito.verify(bidDaoImpl).savePlaceBidDetails(bidDto);
		Assert.assertEquals(BidConstants.ACTIVE,bidDto.getPropertyStatus());
	}
}
