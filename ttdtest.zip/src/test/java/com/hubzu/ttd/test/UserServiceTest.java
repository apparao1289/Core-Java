package com.hubzu.ttd.test;

import org.mockito.Mockito;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hubzu.ttd.user.HubzuServiceException;
import com.hubzu.ttd.user.UserDaoImpl;
import com.hubzu.ttd.user.UserDto;
import com.hubzu.ttd.user.UserService;
import com.hubzu.ttd.user.UserServiceImpl;

public class UserServiceTest {
	
	UserService userService = null;
	UserDaoImpl userDaoImpl = null;
	
	@BeforeClass
	public void init(){
		userDaoImpl = Mockito.mock(UserDaoImpl.class);
		userService = new UserServiceImpl(userDaoImpl);
	}
	
	@Test
	public void testUser(){
		Assert.assertNotNull(userService);
	}
	
	@Test(expectedExceptions = HubzuServiceException.class)
	public void saveUserInformation() throws HubzuServiceException{
		UserDto userDto = null;
		Assert.assertEquals(userService.saveUser(userDto),false);
				
	}
	
	@Test(expectedExceptions = HubzuServiceException.class)
	public void saveUserMandatoryFirstNameInformation() throws HubzuServiceException{
		UserDto userDto = new UserDto();
		userDto.setFirstName("Rao");
		Assert.assertEquals(userService.saveUser(userDto),true);
				
	}
	
	@Test(expectedExceptions = HubzuServiceException.class)
	public void saveUserMandatoryLastNameInformation() throws HubzuServiceException{
		UserDto userDto = new UserDto();
		userDto.setFirstName("Rao");
		userDto.setLastName(null);
		Assert.assertEquals(userService.saveUser(userDto),false);
				
	}
	
	@Test(expectedExceptions = HubzuServiceException.class)
	public void saveUserMandatoryEmailInformation() throws HubzuServiceException{
		UserDto userDto = new UserDto();
		userDto.setFirstName("Rao");
		userDto.setLastName("Gongada");
		userDto.setEmail(null);
		Assert.assertEquals(userService.saveUser(userDto),true);
	}
	
	@Test(expectedExceptions = HubzuServiceException.class)
	public void saveUserMandatoryPasswordInformation() throws HubzuServiceException{
		UserDto userDto = new UserDto();
		userDto.setFirstName("Rao");
		userDto.setLastName("Gongada");
		userDto.setEmail("test@gmail.com");
		userDto.setPassword(null);
		Assert.assertEquals(userService.saveUser(userDto),true);
	}
	
	@Test
	public void saveUserMandatoryInformation() throws HubzuServiceException{
		UserDto userDto = new UserDto();
		userDto.setFirstName("Rao");
		userDto.setLastName("Gongada");
		userDto.setEmail("test@gmail.com");
		userDto.setPassword("assdD2g");
		Mockito.when(userDaoImpl.checkUserExists(userDto)).thenReturn(false);
		Mockito.when(userDaoImpl.saveUser(userDto)).thenReturn(true);
		Assert.assertEquals(userService.saveUser(userDto),true);
	}
	
	@Test(expectedExceptions = HubzuServiceException.class)
	public void userAlreadyExists() throws HubzuServiceException{
		UserDto userDto = new UserDto();
		userDto.setFirstName("Rao");
		userDto.setLastName("Gongada");
		userDto.setEmail("test@gmail.com");
		userDto.setPassword("assdD2g");
		Mockito.when(userDaoImpl.checkUserExists(userDto)).thenReturn(true);
		Mockito.when(userDaoImpl.saveUser(userDto)).thenReturn(false);
		Assert.assertEquals(userService.saveUser(userDto),true);
	}
	
	@Test
	public void saveUser() throws HubzuServiceException{
		UserDto userDto = new UserDto();
		userDto.setFirstName("Rao");
		userDto.setLastName("Gongada");
		userDto.setEmail("test@gmail.com");
		userDto.setPassword("assdD2g");
		Mockito.when(userDaoImpl.checkUserExists(userDto)).thenReturn(false);
		Mockito.when(userDaoImpl.saveUser(userDto)).thenReturn(true);
		Assert.assertEquals(userService.saveUser(userDto),true);
	}
	
	@Test
	public void saveUser2() throws HubzuServiceException{
		UserDto userDto = new UserDto();
		userDto.setFirstName("Rama");
		userDto.setLastName("rao");
		userDto.setEmail("test1@gmail.com");
		userDto.setPassword("wqwqewr2");
		Mockito.when(userDaoImpl.checkUserExists(userDto)).thenReturn(false);
		Mockito.when(userDaoImpl.saveUser(userDto)).thenReturn(true);
		Assert.assertEquals(userService.saveUser(userDto),true);
	}
}
