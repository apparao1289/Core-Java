package com.hubzu.ttd;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PassWordValidateTest {
	
	public static final Logger logger = Logger.getLogger(PassWordValidateTest.class);
	
	PasswordValidator passwordValidator = null;
	
	@BeforeClass
	public void init(){
		logger.info("init ...");
		passwordValidator = new PasswordValidator();
	}
	
	public void clear(){
		logger.info("clear ...");
	}
	
	@Test
	private void testPasswordValidator() {
		
		PasswordValidator passwordValidator = new PasswordValidator();
		Assert.assertNotNull(passwordValidator);
	}
	
	@Test
	private void testPasswordLength() {
		logger.info("testPasswordLength..");
		Assert.assertEquals(passwordValidator.validatePassword("s2segaS"),true);
	}
	
	@Test
	private void testPasswordContainAtleastOneDigit() {
		Assert.assertEquals(passwordValidator.validatePassword("sefgas6D"),true);
	}
	
	@Test
	private void testPasswordContainAtleastOneLowercaseLetter() {
		Assert.assertEquals(passwordValidator.validatePassword("DDFaAS3"),true);
	}
	
	@Test
	private void testPasswordContainAtleastOneUppercaseLetter() {
		Assert.assertEquals(passwordValidator.validatePassword("asdfe6D"),true);
	}
	
	@Test(dataProviderClass = TestNgPasswordDataProvider.class, dataProvider = "testPasswordString")
	private void testPasswordContainAllCombinations(String password, boolean result) {
		Assert.assertEquals(passwordValidator.validatePassword(password),true);
	}

}
