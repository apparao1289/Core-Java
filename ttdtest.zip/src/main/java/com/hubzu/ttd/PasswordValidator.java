package com.hubzu.ttd;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;
/**
 * This class used for validating the password.
 * @author gongadaa
 *
 */
public class PasswordValidator {
	
	public static final Logger logger = Logger.getLogger(PasswordValidator.class);
	
	public ResourceBundle resourceBundle = ResourceBundle.getBundle("Messages");
	
	/**
	 * This method validate the given password is valid or not.
	 * @param password
	 * @return
	 */
	public boolean validatePassword(String password) {
		logger.info("password:::"+password);
		if (null != password && password.length() >= 6 && password.length() <= 8) {
			byte[] bytes = password.getBytes(); 
			if(isDigitExists(bytes) && isLowerCaseLetterExists(bytes) && isUpperCaseLetterExists(bytes)){
				return true;
			}else{
				throw new RuntimeException(resourceBundle.getString(
						PasswordCOnstants.PASS_WORD_CONTAIN_ONEDIGIT_ONELOWER_ONEUPPER_LETTER));
			}
		}else{
			throw new RuntimeException(resourceBundle.getString(PasswordCOnstants.PASS_WORD_LENGTH));
		}
	}
	
	/**
	 * This method checks, at least one digit exists for given password.
	 * @param bytes
	 * @return
	 */
	private boolean isDigitExists(byte[] bytes) {
		for(byte b:bytes){
			 char inChar = (char) b;
			if(Character.isDigit(inChar)){
				logger.info("it is digit.."+inChar);
				return true;
			}
		}
		return false;
	}
	
	/**
	 * This method checks, at least one lower case letter exists for given password.
	 * @param bytes
	 * @return
	 */
	private boolean isLowerCaseLetterExists(byte[] bytes) {
		for(byte b:bytes){
			 char inChar = (char) b;
			if(Character.isLowerCase(inChar)){
				logger.info("lower case.."+inChar);
				return true;
			}
		}
		return false;
	}
	
	/**
	 * This method checks, at least one upper case letter exists for given password.
	 * @param bytes
	 * @return
	 */
	private boolean isUpperCaseLetterExists(byte[] bytes) {
		for(byte b:bytes){
			 char inChar = (char) b;
			if(Character.isUpperCase(inChar)){
				logger.info("upper case.."+inChar);
				return true;
			}
		}
		return false;
	}
}
