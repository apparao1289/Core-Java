package com.hubzu.ttd.bid;

import com.hubzu.ttd.user.HubzuServiceException;

public interface BidService {

	boolean placeBid(BidDto bidDto) throws HubzuServiceException;

}
