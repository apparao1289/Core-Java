package com.hubzu.ttd.bid;

import com.hubzu.ttd.user.HubzuServiceException;
/**
 * This class provides the functionality for place bid operations.
 * @author gongadaa
 *
 */
public class BidDaoImpl {
	
	/**
	 * This method will return the current highest bid amount.
	 * @return
	 * @throws HubzuServiceException
	 */
	public int getCurrentHighestBidOnListing() throws HubzuServiceException {
		return 0;
	}
	
	/**
	 * This method will return the true/false based on the buyer verification.
	 * @param bidDto
	 * @return
	 */
	public boolean verifyBuyerDetails(BidDto bidDto) {
		return false;
	}
	
	/**
	 * This method persists the bid information to database.
	 * @param bidDto
	 * @return
	 */
	public boolean savePlaceBidDetails(BidDto bidDto) {
		return false;
	}
}
