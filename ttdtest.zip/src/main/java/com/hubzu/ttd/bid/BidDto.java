package com.hubzu.ttd.bid;

import java.io.Serializable;

public class BidDto implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String buyerEmailId;
	private String firstName;
	private String lastName;
	private double bidAmount;
	private String bidType;
	private String propertyStatus;
	
	/**
	 * @return the buyerEmailId
	 */
	public String getBuyerEmailId() {
		return buyerEmailId;
	}
	/**
	 * @param buyerEmailId the buyerEmailId to set
	 */
	public void setBuyerEmailId(String buyerEmailId) {
		this.buyerEmailId = buyerEmailId;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the bidAmount
	 */
	public double getBidAmount() {
		return bidAmount;
	}
	/**
	 * @param bidAmount the bidAmount to set
	 */
	public void setBidAmount(double bidAmount) {
		this.bidAmount = bidAmount;
	}
	/**
	 * @return the bidType
	 */
	public String getBidType() {
		return bidType;
	}
	/**
	 * @param bidType the bidType to set
	 */
	public void setBidType(String bidType) {
		this.bidType = bidType;
	}
	/**
	 * @return the propertyStatus
	 */
	public String getPropertyStatus() {
		return propertyStatus;
	}
	/**
	 * @param propertyStatus the propertyStatus to set
	 */
	public void setPropertyStatus(String propertyStatus) {
		this.propertyStatus = propertyStatus;
	}
	

}
