package com.hubzu.ttd.bid;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.hubzu.ttd.user.HubzuServiceException;
import com.hubzu.ttd.user.UserServiceImpl;
/**
 * This class handle the place bid functionality. 
 * @author gongadaa
 *
 */
public class BidServiceImpl implements BidService {
	
	public static final Logger logger = Logger.getLogger(UserServiceImpl.class);
	public static final ResourceBundle resourceBundle = ResourceBundle.getBundle("Messages");
	public BidDaoImpl bidDaoImpl;
	
	public BidServiceImpl(BidDaoImpl bidDaoImpl) {
		this.bidDaoImpl = bidDaoImpl;
	}
	
	/**
	 * This method verifies the buyer details, base on verification, it persist the bid details to 
	 * Data base.
	 * @param bidDto
	 * @return true
	 */
	public boolean placeBid(BidDto bidDto) throws HubzuServiceException {
		
		if(null != bidDto){
			     // Step1: Check the bid amount is greater than zero or not.
			if(bidDto.getBidAmount() > 0){
				int currentHighestBid = bidDaoImpl.getCurrentHighestBidOnListing();
				// Step2: Check bid amount greater than the current highest bid or not.
				if(bidDto.getBidAmount() > currentHighestBid){
					// Step3: verify the buyer details.
					boolean verifyFlag = bidDaoImpl.verifyBuyerDetails(bidDto);
					// Step4: Based on Bid type update the property status.
					updatePropertyStatus(bidDto);
					if(verifyFlag){
						return bidDaoImpl.savePlaceBidDetails(bidDto);
					}
				}else{
					throw new HubzuServiceException(resourceBundle.getString(
							BidConstants.BID_AMOUNT_CANOT_LESS_THAN_CUURENT_HIGH_BID));
				}
			}else{
				throw new HubzuServiceException(resourceBundle.getString(BidConstants.BID_AMOUNT_CANOTBE_ZERO));
			}
		}
		return false;
	}
	
	/**
	 * This method updated the property status based on the bid type.
	 * @param bidDto
	 */
	private void updatePropertyStatus(BidDto bidDto) {
		if (BidConstants.BID_TYPE.equalsIgnoreCase(bidDto.getBidType())) {
			bidDto.setPropertyStatus(BidConstants.SPND);
		} else {
			bidDto.setPropertyStatus(BidConstants.ACTIVE);
		}
	}

}
