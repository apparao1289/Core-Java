package com.hubzu.ttd.bid;

public class BidConstants {
	
	public static final String BID_AMOUNT_CANOTBE_ZERO = "BID_AMOUNT_CANOTBE_ZERO";
	public static final String BID_AMOUNT_CANOT_LESS_THAN_CUURENT_HIGH_BID = "BID_AMOUNT_CANOT_LESS_THAN_CUURENT_HIGH_BID";
	public static final String ACTIVE = "ACTV";
	public static final String SPND = "SPND";
	public static final String BID_TYPE = "Own It Now";

}
