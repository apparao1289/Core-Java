package com.hubzu.ttd.user;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

import sun.misc.BASE64Encoder;
/**
 * This class process the encrypt password logic
 * @author gongadaa
 *
 */
public class PasswordEncryptUtil {

	public static final Logger logger = Logger.getLogger(PasswordEncryptUtil.class);
	
	/**
	 * This method gets the encrypted password.
	 * @param password
	 * @param algorithm
	 * @param encoding
	 * @return
	 * @throws HubzuServiceException
	 */
	public synchronized String getEncryptPassword(final String password, final String algorithm, 
			final String encoding) throws HubzuServiceException {
		
		logger.info("password:: "+password);
		MessageDigest msgDigest = null;
		String encryptPassword = null;
		try {
			msgDigest = MessageDigest.getInstance(algorithm);
			msgDigest.update(password.getBytes(encoding));
			byte rawByte[] = msgDigest.digest();
			encryptPassword = (new BASE64Encoder()).encode(rawByte);

		} catch (NoSuchAlgorithmException e) {
			throw new HubzuServiceException("No Such Algorithm Exists");
		} catch (UnsupportedEncodingException e) {
			throw new HubzuServiceException("The Encoding Is Not Supported");
		}
		logger.info("Encrypted password password:: "+encryptPassword);
		return encryptPassword;
	}

}
