package com.hubzu.ttd.user;

public class HubzuServiceException extends Exception{
	
	private static final long serialVersionUID = 1L;
	
	private String errorCode;
	
	public HubzuServiceException() {
		super("Exception occurred in Core Application.");
	}
	
	
	/**
	 * Constructs a HubzuServiceException with a message describing the exception, 
	 * and the corresponding errorCode
	 */
	public HubzuServiceException(String message, String errorCode) {
		super(message);
		this.errorCode = errorCode;
	}	
	
	/**
	 * Constructs a HubzuServiceException with the exception causing the abort, and the ErrorCode 
	 */
	public HubzuServiceException(Throwable err, String errorCode) {
		super(err);
		this.errorCode = errorCode;
	}	

	public HubzuServiceException(String message) {
		super(message);
		
	}

	public HubzuServiceException(Throwable err) {
		super(err);
		
	}

	public HubzuServiceException(String message, Throwable err) {
		super(message, err);
		
	}

	/**
	 * Constructs a HubzuServiceException with the exception causing the abort, 
	 * and the ErrorCode, and the error  message 
	 */
	public HubzuServiceException(String message, Throwable err, String errorCode) {
		super(message,err);
		this.errorCode = errorCode;
	}
	
	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Constructs a HubzuServiceException with the exception causing the abort, and the ErrorCode, 
	 * and the error  message 
	 */
	public HubzuServiceException(Throwable err, String errorCode, String message) {
		super(message,err);
		this.errorCode = errorCode;
	}

}
