package com.hubzu.ttd.user;

public class UserDaoImpl {
	
	/**
	 * This method checks user exists or not.
	 * @param userDto
	 * @return
	 */
	public boolean checkUserExists(UserDto userDto) {
		return true;
	}
	
	/**
	 * This method persists the user information
	 * @param userDto
	 * @return
	 */
	public boolean saveUser(UserDto userDto) {
		return false;
	}

}
