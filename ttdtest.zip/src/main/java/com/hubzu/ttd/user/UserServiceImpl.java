package com.hubzu.ttd.user;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;
/**
 * This class saves the user information
 * @author gongadaa
 *
 */
public class UserServiceImpl implements UserService {
	
	public static final Logger logger = Logger.getLogger(UserServiceImpl.class);
	public static final ResourceBundle resourceBundle = ResourceBundle.getBundle("Messages");
	
	public UserDaoImpl userDaoImpl = null;
	public PasswordEncryptUtil passwordEncryptUtil = null;
	
	public UserServiceImpl(UserDaoImpl userDaoImpl) {
		this.userDaoImpl = userDaoImpl;
		this.passwordEncryptUtil = new PasswordEncryptUtil();
	}
	
	/**
	 * This method checks if user is exists or not. If user is not exists then persists the 
	 * user information to database.
	 * @param userDto
	 * @return
	 * @throws HubzuServiceException
	 */
	public boolean saveUser(UserDto userDto) throws HubzuServiceException{
		logger.info("saveUser starting...");
		if(null != userDto){
			boolean isDataValid = mandatoryInformationCheck(userDto);
			if(isDataValid){
				// Step1: Check Given Email Id exists or not.
				boolean userExists = userDaoImpl.checkUserExists(userDto);
				if(!userExists){
					// Step2: Get the Encrypted password.
					String encryptPassword = passwordEncryptUtil.getEncryptPassword(
							userDto.getPassword(),UserConstants.ALGORITHAM,UserConstants.ENCODING);
					userDto.setPassword(encryptPassword);
					// Step3: Persist the user information to Data Base.
					return userDaoImpl.saveUser(userDto);
				}else{
					throw new HubzuServiceException(resourceBundle.getString(UserConstants.USER_EXISTS));
				}
			}else{
				throw new HubzuServiceException(resourceBundle.getString(
						UserConstants.MANDATORY_INFORMATION_MISSING));
			}
		}else{
			throw new HubzuServiceException(resourceBundle.getString(
					   UserConstants.USER_DETAILS_CAN_NOT_BE_NULL));
		}
	}
	
	/**
	 * This method validates the mandatory information
	 * @param userDto
	 * @return
	 * @throws HubzuServiceException
	 */
	private boolean mandatoryInformationCheck(UserDto userDto) throws HubzuServiceException{
		
		if(userDto.getFirstName() == null){
			throw new HubzuServiceException("First Name can not be null");
		}
		
		if(userDto.getLastName() == null){
			throw new HubzuServiceException("Last Name can not be null");
		}
		
		if(userDto.getEmail() == null){
			throw new HubzuServiceException("Email can not be null");
		}
		
		if(userDto.getPassword() == null){
			throw new HubzuServiceException("Pass word can not be null");
		}
		return true;
	}
}
