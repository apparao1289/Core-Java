package com.hubzu.ttd.user;

public interface UserService {

	boolean saveUser(UserDto userDto) throws HubzuServiceException;


}
