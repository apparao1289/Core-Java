package com.hubzu.ttd.user;

public class UserConstants {
	public static final String ALGORITHAM = "SHA";
	public static final String ENCODING = "UTF-8";
	public static final String USER_EXISTS = "USER_EXISTS";
	public static final String MANDATORY_INFORMATION_MISSING = "MANDATORY_INFORMATION_MISSING";
	public static final String USER_DETAILS_CAN_NOT_BE_NULL = "USER_DETAILS_CAN_NOT_BE_NULL";
	
}
