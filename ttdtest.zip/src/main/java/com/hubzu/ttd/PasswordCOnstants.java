package com.hubzu.ttd;

public class PasswordCOnstants {
	public static final String PASS_WORD_LENGTH = "PASS_WORD_LENGTH";
	public static final String PASS_WORD_CONTAIN_ONEDIGIT_ONELOWER_ONEUPPER_LETTER = 
			"PASS_WORD_CONTAIN_ONEDIGIT_ONELOWER_ONEUPPER_LETTER";

}
