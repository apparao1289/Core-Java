package com.hubzu.ttd;

import org.testng.annotations.DataProvider;

public class TestNgPasswordDataProvider {
	
	@DataProvider
	public static Object[][] testPasswordString(){
		return new Object[][] {
				{"asdf2qeD",true},
				{"234sdafs",true},
				{"aafadsfddafffadsf",false},
				{"ASDFGHJ",false},
				{"asdQwe2c",true},
				{"asdQ87we,;&^%^^2c",false},
				{"asdQ87werawio;dsa<fsz.kjfczsfh",false},
				{"asdQ87w2433255756t",false},
				{"SSDDDDIUY",false},
				};
	}
}
