package com.zuners.listingsws;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;

public class DynamoDBTest {

	public static void main(String[] args) {
		
		BasicAWSCredentials credentials = new 
				BasicAWSCredentials("AKIAJ2ROSBGUH7FUIHAA", 
						"zZPNo1MZG+dQnMrLUArPAcaViRjuvYnbPo7x4Lsc");
		AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient(credentials) ;
		dynamoDBClient.setEndpoint("dynamodb.us-east-1.amazonaws.com");  
//		DynamoDB dynamo = new DynamoDB(new AmazonDynamoDBClient(
//	            new ProfileCredentialsProvider()));
		
		DynamoDB dynamo = new DynamoDB(dynamoDBClient);
		
		Table table = dynamo.getTable("listing");
//		
//		Listing listing = new Listing("123", 4444400);
//		
//		Gson gson = new Gson();
//		String json = gson.toJson(listing); 
//
//		Item item =
//		  new Item()
//		      .withPrimaryKey("id", "123")
//		      .withJSON("document", json);
//
//		table.putItem(item);
		
		Item documentItem =
				  table.getItem(new GetItemSpec()
				                .withPrimaryKey("id", "123")
				                .withAttributesToGet("document"));

				System.out.println(documentItem.getJSONPretty("document"));

	}

}
