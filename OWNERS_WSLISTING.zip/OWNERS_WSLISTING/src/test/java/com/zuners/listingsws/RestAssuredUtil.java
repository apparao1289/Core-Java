package com.zuners.listingsws;

import com.jayway.restassured.RestAssured;

public class RestAssuredUtil
{
    public static final void setup()
    {
        RestAssured.baseURI  = "http://wslisting.dev.us-east-1.hubzu.com";
        RestAssured.port     = 80;
        RestAssured.basePath = "/listingsws/2015-08-01/listings";
    }
}
