package com.zuners.listingsws;

import static com.jayway.restassured.RestAssured.expect;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ListingControllerTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		RestAssuredUtil.setup();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFetch() {
		expect().statusCode(200).when().get( "/fetch?id=141020101//1274132" );
	}

}
