package com.zuners.listingsws.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.zuners.listingsws.common.CommonUtils;
import com.zuners.listingsws.decorator.ResponseDecorator;
import com.zuners.listingsws.domain.Listing;
import com.zuners.listingsws.dto.PropertyDetailsSource;
import com.zuners.listingsws.request.ListingRequest;

@Service
public class ListingServiceImpl implements ListingService {

    @Resource
    private Environment environment;

    @Resource
    private DAOFactory daoFactory;
    
    @Autowired
    CommonUtils commonUtils;

    @Autowired
    List< ResponseDecorator > responseDecoratorsList;

    @Override
    public String getById( ListingRequest listingRequest ) {
        String response = daoFactory.getDao( listingRequest.getCohort() ).getById( listingRequest.getId(), listingRequest.getVersion());
        if (!CollectionUtils.isEmpty( responseDecoratorsList )) {
            for ( ResponseDecorator responseDecorator : responseDecoratorsList ) {
                response = responseDecorator.decorate( listingRequest, response );
            }
        }
        return response;
    }

    @Override
	public void add( Listing listing ) {
    	daoFactory.getDao("mls").add(listing);
    }

    @Override
    public void delete( String id ) {
        // TODO
    }
    
    @Override
    public String getMlsLastUpdatedDate( String mlsId) {
        return daoFactory.getDao("mls").getMlsLastUpdatedDate( mlsId );
    }

	@Override
	public void add(PropertyDetailsSource propertyDetailsSource) {
		daoFactory.getDao("mls").add(propertyDetailsSource);
		
	}

}
