package com.zuners.listingsws.decorator.impl;

import static com.zuners.listingsws.common.Constants.JSON_TAG_DATA;
import static com.zuners.listingsws.common.Constants.JSON_TAG_USER_FAVORITE;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_D;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_KEY;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_VALUE;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.hubzu.common.logger.HubzuLog;
import com.zuners.listingsws.common.CommonUtils;
import com.zuners.listingsws.common.JsonUtil;
import com.zuners.listingsws.dao.OwnersAPIClient;
import com.zuners.listingsws.decorator.ResponseDecorator;
import com.zuners.listingsws.request.ListingRequest;

@Service
@Order( value = 1 )
public class UserFavoriteResponseDecorator implements ResponseDecorator {

    private static final String USER_FAVORITE_DEFAULT_VALUE = "false";

    private final static HubzuLog logger = HubzuLog.getLogger( UserFavoriteResponseDecorator.class );

    private static final String USER_FAVORITE_ATTRIBUTE = "favorite";

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    OwnersAPIClient ownersAPIClient;

    @Override
    public String decorate( ListingRequest request, String response ) {
        logger.debug( "Calling User Favorite Decorator" );
        String pdpUserFavoriteInfo = USER_FAVORITE_DEFAULT_VALUE;
        if (!StringUtils.isEmpty( response ) && !StringUtils.isEmpty( request.getUserId() )
                && commonUtils.isAdditionalAttribute( USER_FAVORITE_ATTRIBUTE )) {
            try {
                String userFavoriteResponse = ownersAPIClient.getUserFavorite( commonUtils.getEscapedPropertyId( request.getId() ),
                        request.getUserId() );
                logger.debug( "Got User Favorite : {}", userFavoriteResponse );
                pdpUserFavoriteInfo = JsonUtil.getResponseFromJson( userFavoriteResponse );
                logger.debug( "Got Actual User Favorite Response : {}", pdpUserFavoriteInfo );
                if (StringUtils.isEmpty( pdpUserFavoriteInfo )) {
                    pdpUserFavoriteInfo = USER_FAVORITE_DEFAULT_VALUE;
                }
            } catch ( Exception e ) {
                logger.error("Error while getting user favourite value so returning false", e);
                pdpUserFavoriteInfo = USER_FAVORITE_DEFAULT_VALUE;
            }
        }
        JSONObject jsonObject = new JSONObject( response );
        JSONArray dataArray = jsonObject.getJSONArray( JSON_TAG_DATA );
        JSONObject userFavoriteObject = new JSONObject();
        userFavoriteObject.put( MLS_PDP_RESPONSE_KEY, JSON_TAG_USER_FAVORITE );
        JSONArray userFavoriteValueObject = new JSONArray();
        userFavoriteValueObject.put( pdpUserFavoriteInfo );
        userFavoriteObject.put( MLS_PDP_RESPONSE_VALUE, userFavoriteValueObject );
        userFavoriteObject.put( MLS_PDP_RESPONSE_D, 0 );
        dataArray.put( userFavoriteObject );
        return jsonObject.toString();
    }

}
