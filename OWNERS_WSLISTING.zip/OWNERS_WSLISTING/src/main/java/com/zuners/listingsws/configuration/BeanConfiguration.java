package com.zuners.listingsws.configuration;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.zuners.listingsws.dao.DynamoDBClient;

@Configuration
public class BeanConfiguration {
    private @Value("${aws_access_key_id}") String keyId;
    private @Value("${aws_secret_access_key}") String key;
    private @Value("${aws_dynamodb_connection_timeout}") String connectTimeout;
    private @Value("${aws_dynamodb_socket_timeout}") String socketTimeout;

    private @Value("${hubzu_aws_dynamodb_end_point:dynamodb.us-east-1.amazonaws.com}") String hubzuDynamoDBEndpoint;
    private @Value("${hubzu_aws_access_key_id}") String hubzuKeyId;
    private @Value("${hubzu_aws_secret_access_key}") String hubzuKey;
    private @Value("${hubzu_aws_dynamodb_connection_timeout}") String hubzuConnectTimeout;
    private @Value("${hubzu_aws_dynamodb_socket_timeout}") String hubzuSocketTimeout;

    private @Value("${hubzu_dr_aws_dynamodb_end_point:dynamodb.us-east-1.amazonaws.com}") String hubzuDrDynamoDBEndpoint;
    private @Value("${hubzu_dr_aws_access_key_id}") String hubzuDrKeyId;
    private @Value("${hubzu_dr_aws_secret_access_key}") String hubzuDrKey;

    @Value("${listingws.max_total_connection:500}")
    private int maxConnectionTotal;
    @Value("${listingws.max_per_route_connection:300}")
    private int maxPerRouteConnection;
    @Value("${listingws.request_timeout:30}")
    private int requestTimeout;

    @Bean(name = "ownersDynamoDB")
    public DynamoDB ownersDynamoDB() {
        BasicAWSCredentials credentials = new BasicAWSCredentials(keyId, key);
        ClientConfiguration clientConfig = new ClientConfiguration();
        clientConfig.setConnectionTimeout(Integer.parseInt(connectTimeout));
        clientConfig.setSocketTimeout(Integer.parseInt(socketTimeout));
        AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient(credentials, clientConfig);
        return new DynamoDB(dynamoDBClient);
    }

    @Bean(name = "hubzuDynamoDB")
    public DynamoDB hubzuDynamoDB() {
        BasicAWSCredentials credentials = new BasicAWSCredentials(hubzuKeyId, hubzuKey);
        ClientConfiguration clientConfig = new ClientConfiguration();
        clientConfig.setConnectionTimeout(Integer.parseInt(hubzuConnectTimeout));
        clientConfig.setSocketTimeout(Integer.parseInt(hubzuSocketTimeout));
        AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient(credentials, clientConfig);
        dynamoDBClient.setEndpoint(hubzuDynamoDBEndpoint);
        return new DynamoDB(dynamoDBClient);
    }

    @Bean(name = "hubzuDrDynamoDB")
    public DynamoDB hubzuDrDynamoDB() {
        if (StringUtils.isNotBlank(hubzuDrDynamoDBEndpoint) && StringUtils.isNotBlank(hubzuDrKeyId)
                && StringUtils.isNotBlank(hubzuDrKey)) {
            BasicAWSCredentials credentials = new BasicAWSCredentials(hubzuDrKeyId, hubzuDrKey);
            ClientConfiguration clientConfig = new ClientConfiguration();
            clientConfig.setConnectionTimeout(Integer.parseInt(hubzuConnectTimeout));
            clientConfig.setSocketTimeout(Integer.parseInt(hubzuSocketTimeout));
            AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient(credentials,
                    clientConfig);
            dynamoDBClient.setEndpoint(hubzuDrDynamoDBEndpoint);
            return new DynamoDB(dynamoDBClient);
        } else {
            return null;
        }
    }

    @Bean(name = "ownersDynamoDBClient")
    public DynamoDBClient ownersDynamoDBClient() {
        DynamoDB dynamoDB = ownersDynamoDB();
        return new DynamoDBClient(dynamoDB);
    }

    @Bean(name = "hubzuDynamoDBClient")
    public DynamoDBClient hubzuDynamoDBClient() {
        DynamoDB dynamoDB = hubzuDynamoDB();
        return new DynamoDBClient(dynamoDB);
    }

    @Bean(name = "hubzuDrDynamoDBClient")
    public DynamoDBClient hubzuDrDynamoDBClient() {
        DynamoDB dynamoDB = hubzuDrDynamoDB();
        if (dynamoDB != null) {
            return new DynamoDBClient(dynamoDB);
        } else {
            return null;
        }
    }

    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate(httpClientFactory());
    }

    @Bean
    ClientHttpRequestFactory httpClientFactory() {
        HttpClient httpClient = HttpClientBuilder.create().setMaxConnTotal(maxConnectionTotal)
                .setMaxConnPerRoute(maxPerRouteConnection).build();
        HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(
                httpClient);
        httpComponentsClientHttpRequestFactory.setConnectTimeout(requestTimeout * 1000);
        httpComponentsClientHttpRequestFactory.setReadTimeout(requestTimeout * 1000);
        httpComponentsClientHttpRequestFactory.setConnectionRequestTimeout(requestTimeout * 1000);
        return httpComponentsClientHttpRequestFactory;
    }
}
