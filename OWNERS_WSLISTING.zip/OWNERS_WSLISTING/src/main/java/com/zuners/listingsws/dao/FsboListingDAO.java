package com.zuners.listingsws.dao;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zuners.listingsws.domain.Listing;
import com.zuners.listingsws.dto.PropertyDetailsSource;

@Service

public class FsboListingDAO implements ListingDAO {

    @Resource
    private OwnersAPIClient ownersAPIClient;

    @Override
    public void delete( String id ) {
        // TODO Auto-generated method stub
    }

    @Override
    public String getById(String id,String version) {
        return ownersAPIClient.getById( id );
    }

    @Override
    public void add( Listing listing ) {
        // TODO Auto-generated method stub

    }

    @Override
    public String getMlsLastUpdatedDate( String boardId ) {
        throw new UnsupportedOperationException("this operation is not supported for FSBO listings");
    }

	@Override
	public void add(PropertyDetailsSource propertyDetailsSource) {
		// TODO Auto-generated method stub
		
	}

}
