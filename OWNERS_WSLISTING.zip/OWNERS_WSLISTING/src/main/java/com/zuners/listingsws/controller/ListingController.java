package com.zuners.listingsws.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.hubzu.common.logger.HubzuLog;
import com.zuners.listingsws.common.Constants;
import com.zuners.listingsws.domain.Listing;
import com.zuners.listingsws.dto.PropertyDetailsSource;
import com.zuners.listingsws.request.ListingRequest;
import com.zuners.listingsws.service.ListingService;

@Controller
@RequestMapping("/2015-08-01/listings")
public class ListingController {
	private static final String ID = "id";
	private static final String COHORT = "cohort";
	private static final String USERID = "userId";

	private final static HubzuLog logger = HubzuLog.getLogger( ListingController.class );

	@Resource
	private ListingService listingService;

	@RequestMapping(value = "fetch", produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String getByIdFromParam(@RequestParam(value = ID) String id, 
			@RequestParam(value = COHORT, required = false, defaultValue = "mls") String cohort,
			@RequestParam(value = USERID, required = false) String userId,
			@RequestParam(value = "version", required = false,defaultValue = "v1") String version) {
	    ListingRequest listingRequest = new ListingRequest();
        listingRequest.setCohort( cohort );
        listingRequest.setId( id );
        listingRequest.setUserId( userId );
        listingRequest.setVersion(version);
		return listingService.getById(listingRequest);
	}

	@RequestMapping(value = "add", params = ID, method = RequestMethod.POST)
	@ResponseBody
	public void addListing(@RequestParam(ID) String id,
			@RequestBody PropertyDetailsSource propertyDetailsSource) {
		listingService.add(propertyDetailsSource);
	}

	@RequestMapping(value = "delete", params = ID, method = RequestMethod.POST)
	@ResponseBody
	public void deleteListing(@RequestParam(ID) String id) {
		listingService.delete(id);
	}

	@ExceptionHandler(Exception.class)
	@ResponseBody
	public Map<String, String> errorResponse(Exception ex,
			HttpServletResponse response) {
		Map<String, String> errorMap = new HashMap<String, String>();
		errorMap.put("Status", Constants.ERROR_RESPONSE);
		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		logger.error("Error ", ex);
		return errorMap;
	}
}
