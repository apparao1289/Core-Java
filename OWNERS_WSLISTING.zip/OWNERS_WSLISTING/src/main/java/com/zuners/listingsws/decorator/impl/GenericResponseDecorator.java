package com.zuners.listingsws.decorator.impl;

import static com.zuners.listingsws.common.Constants.JSONPATH_LISTING_DATE;
import static com.zuners.listingsws.common.Constants.JSON_TAG_DATA;
import static com.zuners.listingsws.common.Constants.JSON_TAG_NO_OF_DAYS;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_D;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_KEY;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_VALUE;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.hubzu.common.logger.HubzuLog;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.zuners.listingsws.common.CommonUtils;
import com.zuners.listingsws.common.DateUtils;
import com.zuners.listingsws.decorator.ResponseDecorator;
import com.zuners.listingsws.request.ListingRequest;

@Service
@Order( value = 3 )
public class GenericResponseDecorator implements ResponseDecorator {

	private final static HubzuLog logger = HubzuLog.getLogger( GenericResponseDecorator.class );

    @Autowired
    CommonUtils commonUtils;

    @Override
    public String decorate( ListingRequest request, String response ) {
        logger.debug( "Calling Generic Response Decorator" );
        try {
            Object document = Configuration.defaultConfiguration().jsonProvider().parse( response );
            String listingDate = "";
            net.minidev.json.JSONArray listingDateJsonArrayOfArray = JsonPath.read( document, JSONPATH_LISTING_DATE );
            if (listingDateJsonArrayOfArray != null && listingDateJsonArrayOfArray.size() > 0) {
                net.minidev.json.JSONArray listingDateArray = ( net.minidev.json.JSONArray ) listingDateJsonArrayOfArray.get( 0 );
                if (listingDateArray != null && listingDateArray.size() > 0) {
                    listingDate = listingDateArray.get( 0 ).toString().trim();
                }
            }
            String noOfDaysInStr = "";
            if (!StringUtils.isEmpty( listingDate )) {
                Long noOfDays = DateUtils.getRemainingDays( listingDate );
                if (noOfDays != null) {
                    noOfDaysInStr = noOfDays + "";
                }
            }
            JSONObject jsonObject = new JSONObject( response );
            JSONArray dataArray = jsonObject.getJSONArray( JSON_TAG_DATA );
            JSONObject noOfDaysObject = new JSONObject();
            noOfDaysObject.put( MLS_PDP_RESPONSE_KEY, JSON_TAG_NO_OF_DAYS );
            JSONArray noOfDaysValueObject = new JSONArray();
            noOfDaysValueObject.put( noOfDaysInStr );
            noOfDaysObject.put( MLS_PDP_RESPONSE_VALUE, noOfDaysValueObject );
            noOfDaysObject.put( MLS_PDP_RESPONSE_D, 0 );
            dataArray.put( noOfDaysObject );
            return jsonObject.toString();
        } catch ( Exception e ) {
            logger.error( "Exception while decorating for number of days", e );
        }
        return response;
    }

}
