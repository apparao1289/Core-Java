package com.zuners.listingsws.service;

import com.hubzu.search.model.property.PropertyAndListingDetails;

public interface PropertyDrService {
    public void add(PropertyAndListingDetails propertyAndListingDetails);

    public void delete(String propertyId);

}
