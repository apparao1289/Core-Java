package com.zuners.listingsws.request;

public class PdpUrlRequest {

    private String addressHash;
    private String zip;
    private String city;
    private String streetNumber;
    private String streetName;
    private String streetSuffix;
    private String suiteName;
    private String suiteNumber;

    public String getAddressHash() {
        return addressHash;
    }

    public void setAddressHash(String addressHash) {
        this.addressHash = addressHash;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreetNumber() {
        return streetNumber;
    }

    public void setStreetNumber(String streetNumber) {
        this.streetNumber = streetNumber;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getStreetSuffix() {
        return streetSuffix;
    }

    public void setStreetSuffix(String streetSuffix) {
        this.streetSuffix = streetSuffix;
    }

    public String getSuiteName() {
        return suiteName;
    }

    public void setSuiteName(String suiteName) {
        this.suiteName = suiteName;
    }

    public String getSuiteNumber() {
        return suiteNumber;
    }

    public void setSuiteNumber(String suiteNumber) {
        this.suiteNumber = suiteNumber;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PdpUrlRequest [addressHash=");
        builder.append(addressHash);
        builder.append(", zip=");
        builder.append(zip);
        builder.append(", city=");
        builder.append(city);
        builder.append(", streetNumber=");
        builder.append(streetNumber);
        builder.append(", streetName=");
        builder.append(streetName);
        builder.append(", streetSuffix=");
        builder.append(streetSuffix);
        builder.append(", suiteName=");
        builder.append(suiteName);
        builder.append(", suiteNumber=");
        builder.append(suiteNumber);
        builder.append("]");
        return builder.toString();
    }

}
