package com.zuners.listingsws.common;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zuners.listingsws.response.MlsPdpResponse;

@Service
public class CommonUtils {
    
    private @Value("${owners_pdp_remove_characters}") String removableCharacters;
    
    private @Value("${owners_pdp_remove_regex}") String removableRegex;
    
    private @Value("${additionalAttributes}") String additionalAttributes;
    
    public String getEscapedPropertyId(String propertyId){
        return propertyId.replace( "/", "" );
    }
    
    public boolean isAdditionalAttribute(String key){
        boolean response = false;
        if(!StringUtils.isEmpty( additionalAttributes )){
            response = additionalAttributes.contains( key );
        }
        return response;
    }

    public String getTagValueViaRegex( String xml, String tag ) {
        final Pattern pattern = Pattern.compile( "<" + tag + "(.+?)</" + tag + ">" );
        final Matcher matcher = pattern.matcher( xml );
        if (matcher.find()) {
            return matcher.group( 1 );
        }
        else {
            return null;
        }
    }

    public String removeUnwantedCharacters(String response){
        if(response!=null){
            /*
             * All characters that are not (^) in the range \x20-\x7E
             * (hex 0x20 to 0x7E) that is characters from space to ~
             * (http://www.asciitable.com/,)
             */
            if(!StringUtils.isEmpty( removableRegex )){
                String[] regexExpressions = removableRegex.split( "," );
                for(String regex :  regexExpressions){
                    response =  response.replaceAll( regex, "" );
                }
            }
            if(!StringUtils.isEmpty( removableCharacters )){
                String[] removableChars = removableCharacters.split( "," );
                for(String chars :  removableChars){
                    response =  response.replace( chars, "" );
                }
            }
            return response;
        } else {
            return null;
        }
    }
    
    public static void main( String[] args ) throws JsonParseException, JsonMappingException, IOException {
        String a = "owner\u20acs";
        System.out.println( a.replace( "\u20ac", "" ) );
        System.out.println( a.replace( "\\u20ac", "" ) );
        System.out.println( a.replace( '\u20ac', ' ' ) );
        a =  a.replaceAll( "[^\\u0000-\\u007F]", "" );
        a =  a.replaceAll( "[^\\x20-\\x7e]", "" );
        String response = "{\n" + 
                "    \"LastUpdatedDate\": \"2015-11-17T06:21:18.343\",\n" + 
                "    \"LastUpdatedDateg\": \"2015-11-17T06:21:18.343\",\n" +
                "    \"IsRebateAvailable\": false\n" + 
                "}";
        ObjectMapper objectMapper = new ObjectMapper();
        MlsPdpResponse mlsPdpResponse = objectMapper.readValue( response, MlsPdpResponse.class );
        System.out.println( mlsPdpResponse );
        System.out.println( "141020101//1272733".replace( "/", "" ) );
    }
    
}
