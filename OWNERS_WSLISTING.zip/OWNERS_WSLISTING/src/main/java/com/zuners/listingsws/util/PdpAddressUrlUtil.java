package com.zuners.listingsws.util;

import org.springframework.stereotype.Component;

import com.hubzu.search.common.enums.ErrorCode;
import com.hubzu.search.common.exception.ApplicationException;
import com.hubzu.search.model.property.PropertyAddress;
import com.zuner.addrserv.model.response.NormalisedAddress;

/**
 * The Class PdpAddressUrlUtil.
 */
@Component
public class PdpAddressUrlUtil {

    private static final String SPACE = " ";
    private static final String HYPHEN = "-";
    private static final String EMPTY = "";

    public String flatAddressForPdpUrl(PropertyAddress propertyAddress) {
        if (propertyAddress == null) {
            throw new ApplicationException("property address cannot be null", ErrorCode.INVALID_PARAMETER);
        }
        StringBuffer sb = new StringBuffer();
        sb.append(getDefault(propertyAddress.getStreetNumber())).append(SPACE);
        sb.append(getDefault(propertyAddress.getStreetName())).append(SPACE);
        sb.append(getDefault(propertyAddress.getZip()).split(HYPHEN)[0]).append(SPACE);
        return escapeSpecialCharacter(sb.toString()).toLowerCase();
    }

    /**
     * Flat address.
     *
     * @param address
     *            the address
     * @return the string
     */
    public String flatAddressForPdpUrl(NormalisedAddress normalisedAddress) {
        if (normalisedAddress == null) {
            throw new ApplicationException("normalised address cannot be null", ErrorCode.INVALID_PARAMETER);
        }
        StringBuffer sb = new StringBuffer();
        sb.append(getDefault(normalisedAddress.getStreetNumber())).append(SPACE);
        sb.append(getDefault(normalisedAddress.getStreetName())).append(SPACE);
        sb.append(getDefault(normalisedAddress.getStreetSuffix())).append(SPACE);

        sb.append(getDefault(normalisedAddress.getZip()).split(HYPHEN)[0]).append(SPACE);
        sb.append(getDefault(normalisedAddress.getSuiteName())).append(SPACE);
        sb.append(getDefault(normalisedAddress.getSuiteNumber())).append(SPACE);

        return escapeSpecialCharacter(sb.toString()).toLowerCase();
    }

    private String escapeSpecialCharacter(String text) {
        return text.replace("~", EMPTY).replace("@", EMPTY).replace("#", EMPTY).replace("$", EMPTY).replace("%", EMPTY)
                .replace("^", EMPTY).replace("&", EMPTY).replace("*", EMPTY).replace("(", EMPTY).replace(")", EMPTY)
                .replace("_", EMPTY).replace("+", EMPTY).replace("=", EMPTY).replace("{", EMPTY).replace("}", EMPTY)
                .replace("|", EMPTY).replace("\\", EMPTY).replace(";", EMPTY).replace(":", EMPTY).replace("\"", EMPTY)
                .replace("'", EMPTY).replace(".", EMPTY).replace(",", EMPTY).replace("<", EMPTY).replace(">", EMPTY)
                .replace("?", EMPTY).replace("/", EMPTY).replace("[", EMPTY).replace("]", EMPTY).replace("-", EMPTY)
                .replaceAll(" +", HYPHEN).replaceAll("-$", "").replaceAll("^-", "").trim();
    }

    /**
     * Gets the default.
     *
     * @param s
     *            the s
     * @return the default
     */
    private String getDefault(String s) {
        if (s == null) {
            return "";
        }
        return s.trim();
    }

}
