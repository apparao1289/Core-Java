package com.zuners.listingsws.common;

public class Constants {

	public static final String DYNAMO_DB_DOCUMENT = "document";
	public static final String DYNAMO_DB_JSON = "json";
	public static final String DYNAMO_DB_KEY = "key";

	public static final String JSON_TAG_DATA = "data";
	public static final String JSON_TAG_VERIFIED_DATE = "verified-date";
	public static final String JSON_TAG_REBATE_SECTION = "rebate-section";
	public static final String JSON_TAG_USER_FAVORITE = "user-favorite";
	public static final String JSON_TAG_NO_OF_DAYS = "no-of-days";
	public static final String JSON_TAG_PDP_URL = "pdp-address-url";
	public static final String JSON_TAG_TAGS = "tags";

	public static final String MLS_PDP_RESPONSE_D = "d";
	public static final String MLS_PDP_RESPONSE_VALUE = "v";
	public static final String MLS_PDP_RESPONSE_KEY = "k";

	public static final String ERROR_RESPONSE = "Error";
	public static final String SUCCESS_RESPONSE = "Success";

	public static final String SEARCH_RESPONSE_UNKNOWN = "\"UNKNOWN\"";

	public static final String JSONPATH_STATE = "$.data..[?(@.k == 'state')].v";
	public static final String JSONPATH_LISTING_AGENT_BROKERAGE = "$.data..[?(@.k == 'la-bkr')].v";
	public static final String JSONPATH_LISTING_DATE = "$.data..[?(@.k == 'list-date')].v";
	public static final String JSONPATH_ADDRESS_HASH = "$.derived-data..[?(@.k == 'derived-normalized-address-hash')].v";
	public static final String JSONPATH_CITY = "$.derived-data..[?(@.k == 'derived-normalized-address-city')].v";
	public static final String JSONPATH_ZIP = "$.derived-data..[?(@.k == 'derived-normalized-address-zip')].v";
	public static final String JSONPATH_STREET_NUMBER = "$.derived-data..[?(@.k == 'derived-normalized-address-street-number')].v";
	public static final String JSONPATH_STREET_NAME = "$.derived-data..[?(@.k == 'derived-normalized-address-street-name')].v";
	public static final String JSONPATH_STREET_SUFFIX = "$.derived-data..[?(@.k == 'derived-normalized-address-street-suffix')].v";
	public static final String JSONPATH_SUITE_NAME = "$.derived-data..[?(@.k == 'derived-normalized-address-suite-name')].v";
	public static final String JSONPATH_SUITE_NUMBER = "$.derived-data..[?(@.k == 'derived-normalized-address-suite-number')].v";
	public static final String JSONPATH_TAGS = "$.data..[?(@.k == 'tags')].v";
	public static final String JSONPATH_PROPERTY_ID_DATA_INDEX_ZERO = "$..data[0].propertyId";
	public static final String JSONPATH_PROPERTY_ID_DATA_INDEX_ITH = "$..data['i'].propertyId";
	public static final String JSONPATH_SELLER_CODE_DATA_INDEX_ITH = "$..data['i'].sellerCode";
	public static final int SEARCH_RESPONSE_INDEX_ZERO = 0;
	public static final int SEARCH_RESPONSE_DELIMITER_INDEX = 9;
	public static final int SEARCH_RESPONSE_MAX_COUNT = 100;
	public static final String SEARCH_RESPONSE_DELIMITER = "//";
	public static final String JSON_TAG_LINKS = "links";
	public static final String JSON_TAG_PHOTOS = "photos";
	public static final String JSON_TAG_CUST_INFO = "is-cust-info-public";


}
