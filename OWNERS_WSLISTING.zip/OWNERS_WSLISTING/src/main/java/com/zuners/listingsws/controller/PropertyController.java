package com.zuners.listingsws.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hubzu.common.logger.HubzuLog;
import com.hubzu.search.model.property.PropertyAndListingDetails;
import com.zuners.listingsws.dto.BaseResponse.Status;
import com.zuners.listingsws.dto.Response;
import com.zuners.listingsws.service.PropertyService;
import com.zuners.listingsws.util.JsonUtil;

/**
 * The Class PropertyController.
 * 
 * @author rajputbh
 */
@RestController
@RequestMapping("/2015-08-01/properties")
public class PropertyController {

	private final static HubzuLog logger = HubzuLog.getLogger(PropertyController.class);

	@Autowired
	private PropertyService propertyService;

	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> add(@RequestBody PropertyAndListingDetails propertyAndListingDetails) {
	    logger.debug("Request to add property : {}", propertyAndListingDetails);
		Response<String> response = new Response<String>();
		try {
			propertyService.add(propertyAndListingDetails);
			response.setResult(propertyAndListingDetails.getPropertyDetails().getPropertyId());
		} catch (Exception e) {
			logger.error("Exception while Onboarding property : {}", JsonUtil.toJsonString(propertyAndListingDetails),
					e);
			response.setStatus(Status.FAILURE);
			response.setMessage(e.getMessage());
		}
		return response;
	}

	@RequestMapping(value = "/{propertyId}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> delete(@PathVariable final String propertyId) {
	    logger.debug("Request to delete property : {}", propertyId);
		Response<String> response = new Response<String>();
		try {
			propertyService.delete(propertyId);
			response.setResult(propertyId);
		} catch (Exception e) {
			logger.error("propertyId : {}", propertyId, e);
			response.setStatus(Status.FAILURE);
			response.setMessage(e.getMessage());
		}
		return response;
	}

	@RequestMapping(value = "/{propertyId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<PropertyAndListingDetails> get(@PathVariable final String propertyId) {
	    logger.debug("Request to get property : {}", propertyId);
		Response<PropertyAndListingDetails> response = new Response<PropertyAndListingDetails>();
		try {
			PropertyAndListingDetails propertyAndListingDetails = propertyService.get(propertyId);
			response.setResult(propertyAndListingDetails);
		} catch (Exception e) {
			logger.error("propertyId : {}", propertyId, e);
			response.setStatus(Status.FAILURE);
			response.setMessage(e.getMessage());
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<List<PropertyAndListingDetails>> get(@RequestParam(value = "propertyId") String[] propertyIdList) {
		Response<List<PropertyAndListingDetails>> response = new Response<List<PropertyAndListingDetails>>();
		try {
			List<PropertyAndListingDetails> propertyAndListingDetailsList = propertyService.get(propertyIdList);
			response.setResult(propertyAndListingDetailsList);
		} catch (Exception e) {
			logger.error("propertyIdList : {}", propertyIdList, e);
			response.setStatus(Status.FAILURE);
			response.setMessage(e.getMessage());
		}
		return response;
	}
}
