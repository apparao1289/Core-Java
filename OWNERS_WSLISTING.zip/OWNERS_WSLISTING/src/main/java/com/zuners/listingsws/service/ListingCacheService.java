package com.zuners.listingsws.service;

import java.io.Serializable;

/**
 * Cache service for ws lsiting.
 * 
 * @author dlp
 *
 */
public interface ListingCacheService {

    public void put(String key, Serializable value);

    public Object get(String key);

    void deleteAll();

}
