package com.zuners.listingsws.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Contains photo details.
 * 
 * @author patelpaw
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
public class PhotoDetails implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The guid. */
    private String guid;

    /** The md5. */
    private String md5;

    /** The sort order. */
    private Integer sortOrder;

    /** The original height. */
    private Integer originalHeight;

    /** The original width. */
    private Integer originalWidth;

    /** The update date. */
    private String updateDate;

    /** The images. */
    private List< ImageSize > images;
    
    private List< PropertyData > data;

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public String getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid
     *            the guid to set
     */
    public void setGuid( String guid ) {
        this.guid = guid;
    }

    /**
     * Gets the md5.
     *
     * @return the md5
     */
    public String getMd5() {
        return md5;
    }

    /**
     * Sets the md5.
     *
     * @param md5
     *            the md5 to set
     */
    public void setMd5( String md5 ) {
        this.md5 = md5;
    }

    /**
     * Gets the sort order.
     *
     * @return the sortOrder
     */
    public Integer getSortOrder() {
        return sortOrder;
    }

    /**
     * Sets the sort order.
     *
     * @param sortOrder
     *            the sortOrder to set
     */
    public void setSortOrder( Integer sortOrder ) {
        this.sortOrder = sortOrder;
    }

    /**
     * Gets the original height.
     *
     * @return the originalHeight
     */
    public Integer getOriginalHeight() {
        return originalHeight;
    }

    /**
     * Sets the original height.
     *
     * @param originalHeight
     *            the originalHeight to set
     */
    public void setOriginalHeight( Integer originalHeight ) {
        this.originalHeight = originalHeight;
    }

    /**
     * Gets the original width.
     *
     * @return the originalWidth
     */
    public Integer getOriginalWidth() {
        return originalWidth;
    }

    /**
     * Sets the original width.
     *
     * @param originalWidth
     *            the originalWidth to set
     */
    public void setOriginalWidth( Integer originalWidth ) {
        this.originalWidth = originalWidth;
    }

    /**
     * Gets the update date.
     *
     * @return the updateDate
     */
    public String getUpdateDate() {
        return updateDate;
    }

    /**
     * Sets the update date.
     *
     * @param updateDate
     *            the updateDate to set
     */
    public void setUpdateDate( String updateDate ) {
        this.updateDate = updateDate;
    }

    /**
     * Gets the images.
     *
     * @return the images
     */
    public List< ImageSize > getImages() {
        return images;
    }

    /**
     * Sets the images.
     *
     * @param images
     *            the images to set
     */
    public void setImages( List< ImageSize > images ) {
        this.images = images;
    }

    /**
     * @return the data
     */
    public List< PropertyData > getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData( List< PropertyData > data ) {
        this.data = data;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "PhotoDetails [guid=" );
        builder.append( guid );
        builder.append( ", md5=" );
        builder.append( md5 );
        builder.append( ", sortOrder=" );
        builder.append( sortOrder );
        builder.append( ", originalHeight=" );
        builder.append( originalHeight );
        builder.append( ", originalWidth=" );
        builder.append( originalWidth );
        builder.append( ", updateDate=" );
        builder.append( updateDate );
        builder.append( ", images=" );
        builder.append( images );
        builder.append( ", data=" );
        builder.append( data );
        builder.append( "]" );
        return builder.toString();
    }

}
