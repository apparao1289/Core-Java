package com.zuners.listingsws.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.hubzu.common.logger.HubzuLog;
import com.hubzu.search.model.property.PropertyAddress;
import com.zuner.addrserv.model.common.Address;
import com.zuner.addrserv.model.enums.DataKey;
import com.zuner.addrserv.model.response.AddressDataResponse;
import com.zuner.addrserv.model.response.NormalisedAddress;
import com.zuners.listingsws.common.ApplicationException;
import com.zuners.listingsws.util.AddressServiceUtil;
import com.zuners.listingsws.util.PdpAddressUrlUtil;

/**
 * The Class PdpUrlServiceImpl.
 * 
 * @author rajputbh
 */
@Service
public class PdpUrlServiceImpl implements PdpUrlService {
	private static final HubzuLog LOGGER = HubzuLog.getLogger(PdpUrlServiceImpl.class);
	@Autowired
	private PdpAddressUrlUtil pdpAddressUrlUtil;

	@Autowired
	private AddressServiceUtil addressServiceUtil;

	@Override
	public String getPdpAddressString(String normalisedAddressHash) {
		AddressDataResponse adr = null;
		List<DataKey> dataKeys = new LinkedList<DataKey>();
		dataKeys.add(DataKey.ADDRESS);
		if (StringUtils.hasText(normalisedAddressHash)) {
			LOGGER.info("fetching normalised address for hash : {}", normalisedAddressHash);
			adr = addressServiceUtil.getAddressDetailsById(normalisedAddressHash, dataKeys);
		}else{
		    throw new ApplicationException("Invalid parameter : normalisedAddressHash is empty");
		}
		if (adr != null && adr.getAddressResponse() != null & adr.getAddressResponse().getNormalisedAddress() != null) {
			return getPdpAddressString(adr.getAddressResponse().getNormalisedAddress());
		} else {
		    throw new ApplicationException("Invalid parameter : normalisedAddressHash is invalid");
		}
	}

	@Override
	public String getPdpAddressString(NormalisedAddress normalisedAddress) {
		return pdpAddressUrlUtil.flatAddressForPdpUrl(normalisedAddress);
	}

	@Override
	public String getPdpAddressString(Address address) {
		AddressDataResponse adr = null;
		List<DataKey> dataKeys = new LinkedList<DataKey>();
		dataKeys.add(DataKey.ADDRESS);
		if (address != null) {
			LOGGER.info("fetching normalised address : {}", address);
			adr = addressServiceUtil.getAddressDetails(address, dataKeys);
		}else{
		    throw new ApplicationException("Invalid parameter : address is empty");
		}
		if (adr != null && adr.getAddressResponse() != null && adr.getAddressResponse().getNormalisedAddress() != null) {
			return getPdpAddressString(adr.getAddressResponse().getNormalisedAddress());
		} else {
		    throw new ApplicationException("address cannot be normalised");
		}
	}

	@Override
	public String getPdpAddressString(PropertyAddress propertyAddress) {
		return pdpAddressUrlUtil.flatAddressForPdpUrl(propertyAddress);
	}

}
