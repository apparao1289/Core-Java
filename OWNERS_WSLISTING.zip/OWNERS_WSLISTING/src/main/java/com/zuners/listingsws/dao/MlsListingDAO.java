package com.zuners.listingsws.dao;
import static com.zuners.listingsws.common.Constants.DYNAMO_DB_JSON;
import static com.zuners.listingsws.common.Constants.DYNAMO_DB_KEY;
import static com.zuners.listingsws.common.Constants.JSONPATH_LISTING_AGENT_BROKERAGE;
import static com.zuners.listingsws.common.Constants.JSONPATH_STATE;
import static com.zuners.listingsws.common.Constants.JSON_TAG_DATA;
import static com.zuners.listingsws.common.Constants.JSON_TAG_REBATE_SECTION;
import static com.zuners.listingsws.common.Constants.JSON_TAG_VERIFIED_DATE;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_D;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_KEY;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_VALUE;

import java.io.IOException;
import java.util.Map;

import javax.annotation.Resource;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.KeyAttribute;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.hubzu.common.logger.HubzuLog;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.zuners.listingsws.common.ApplicationException;
import com.zuners.listingsws.domain.Listing;
import com.zuners.listingsws.dto.PropertyDetailsSource;
import com.zuners.listingsws.response.MlsPdpResponse;
import com.zuners.listingsws.service.StateAbbreviationService;

@Service
public class MlsListingDAO implements ListingDAO {

	private final static HubzuLog logger = HubzuLog.getLogger( MlsListingDAO.class );

	private @Value("${aws_dynamodb_table_name}") String tableName;
	
	@Value("${aws_dynamodb_table_name.v2}")
	private String tableNameV2;
	
	private static final String VERSION = "v2";
	
	@Resource(name = "ownersDynamoDBClient")
    private DynamoDBClient ownersDynamoDBClient;

    @Resource
    private OwnersAPIClient ownersAPIClient;

    @Autowired
    private StateAbbreviationService stateAbbreviationService;

    @Override
	public void add( Listing listing ) {
        Table table = ownersDynamoDBClient.getTable(tableNameV2);
        Item item = new Item().withPrimaryKey( DYNAMO_DB_KEY, listing.getId() ).withJSON( DYNAMO_DB_JSON, listing.getDocument());
        table.putItem( item );
    }

	@Override
    public void delete( String id ) {
        Table table = ownersDynamoDBClient.getTable(tableName);
        KeyAttribute primaryKey = new KeyAttribute( DYNAMO_DB_KEY, id );
        table.deleteItem( primaryKey );
    }

    @Override
    public String getById(String id,String version) {
        Table table =  null;
        logger.debug( "Request to fetch pdp details for id: {}", id);
        
        if(VERSION.equalsIgnoreCase(version)) {
        	table = ownersDynamoDBClient.getTable(tableNameV2);
        } else {
        	table = ownersDynamoDBClient.getTable(tableName);
        }
        if (table != null) {
            Item item = table.getItem( DYNAMO_DB_KEY, id );
            if (item != null) {
                Map< String, Object > map = item.asMap();
                Object object = map.get( DYNAMO_DB_JSON );
                if (object != null) {
                    logger.debug( "Response for pdp details for id: {} is {}", id, object );
                    String jsonResponse = object.toString();
                    Object document = Configuration.defaultConfiguration().jsonProvider().parse( jsonResponse );
                    String response = addPdpValuesForMlsPdp( id, jsonResponse, document );
                    return response;
                }
            }
        }
        logger.error( "No Mls Details found for id : {}", id );
        throw new ApplicationException( "No Mls details found for id : " + id );
    }
    
    @Override
    public String getMlsLastUpdatedDate( String boardId) {
        return ownersAPIClient.getMlsLastUpdatedDate( boardId );
    }

    private String addPdpValuesForMlsPdp( String id, String response, Object document ) {
        JSONObject jsonObject = new JSONObject( response );
        JSONArray dataArray = jsonObject.getJSONArray( JSON_TAG_DATA );
        appendPdpValues( id, dataArray, document );
        return jsonObject.toString();
    }

    private void appendPdpValues( String id, JSONArray dataArray, Object document ) {
        int index = id.indexOf( "/" );
        if (dataArray != null && index != -1) {
            MlsPdpResponse response = getPdpDataFromOwners( id, document, index );
            logger.debug( "Response from owners for id: {} is : {}", id, response );
            if (response != null) {
                JSONObject verifiedTimeObject = new JSONObject();
                verifiedTimeObject.put( MLS_PDP_RESPONSE_KEY, JSON_TAG_VERIFIED_DATE );
                JSONArray verifiedTimeValueObject = new JSONArray();
                if (response.getLastUpdatedDate() != null) {
                    verifiedTimeValueObject.put( response.getLastUpdatedDate() );
                    verifiedTimeObject.put( MLS_PDP_RESPONSE_VALUE, verifiedTimeValueObject );
                }
                else {
                    verifiedTimeObject.put( MLS_PDP_RESPONSE_VALUE, JSONObject.NULL );
                }
                verifiedTimeObject.put( MLS_PDP_RESPONSE_D, 0 );
                dataArray.put( verifiedTimeObject );

                JSONObject rebateSectionObject = new JSONObject();
                rebateSectionObject.put( MLS_PDP_RESPONSE_KEY, JSON_TAG_REBATE_SECTION );
                JSONArray rebateSectionValueObject = new JSONArray();
                rebateSectionValueObject.put( response.isRebateAvailable() + "" );
                rebateSectionObject.put( MLS_PDP_RESPONSE_VALUE, rebateSectionValueObject );
                rebateSectionObject.put( MLS_PDP_RESPONSE_D, 0 );
                dataArray.put( rebateSectionObject );
            }
        }
    }

    private MlsPdpResponse getPdpDataFromOwners( String id, Object document, int index ) {
        String mapSetId = id.substring( 0, index );
        String state = "";
        String listingAgentBrokerage = "";
        net.minidev.json.JSONArray listingAgentBrokerJsonArrayOfArray = JsonPath.read( document, JSONPATH_LISTING_AGENT_BROKERAGE );
        net.minidev.json.JSONArray stateJsonArrayOfArray = JsonPath.read( document, JSONPATH_STATE );
        if (listingAgentBrokerJsonArrayOfArray != null && listingAgentBrokerJsonArrayOfArray.size() > 0) {
            net.minidev.json.JSONArray listingAgentBrokerageArray = ( net.minidev.json.JSONArray ) listingAgentBrokerJsonArrayOfArray.get( 0 );
            if (listingAgentBrokerageArray != null && listingAgentBrokerageArray.size() > 0) {
                listingAgentBrokerage = listingAgentBrokerageArray.get( 0 ).toString().trim();
            }
        }
        if (stateJsonArrayOfArray != null && stateJsonArrayOfArray.size() > 0) {
            net.minidev.json.JSONArray stateJsonArray = ( net.minidev.json.JSONArray ) stateJsonArrayOfArray.get( 0 );
            if (stateJsonArray != null && stateJsonArray.size() > 0) {
                state = stateJsonArray.get( 0 ).toString().trim();
                if (state != null && state.trim().length() > 2) {
                    state = stateAbbreviationService.getStateAbbreviation( state );
                }
            }
        }
        String response = ownersAPIClient.getPdpValues( mapSetId, state, listingAgentBrokerage );
        if (response != null) {
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                MlsPdpResponse mlsPdpResponse = objectMapper.readValue( response, MlsPdpResponse.class );
                return mlsPdpResponse;
            } catch ( IOException e ) {
                logger.error( "Error while parsing response from owners", e );
            }
        }
        return null;
    }
    
	@Override
	public void add(PropertyDetailsSource propertyDetailsSource) {
		Gson gson = new Gson();
		String jsonValue = gson.toJson(propertyDetailsSource);
		Table table = ownersDynamoDBClient.getTable(tableNameV2);
        Item item = new Item().withPrimaryKey( DYNAMO_DB_KEY, propertyDetailsSource.getKey()).withString( DYNAMO_DB_JSON, jsonValue);
        table.putItem( item );
		
	}
}
