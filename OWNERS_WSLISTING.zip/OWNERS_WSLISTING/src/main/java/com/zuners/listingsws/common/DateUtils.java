package com.zuners.listingsws.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.util.StringUtils;

import com.hubzu.common.logger.HubzuLog;

public class DateUtils {

    public static final String LIST_DATE_FORMAT = "MM/dd/yyyy hh:mm:ss a";
    
    private final static HubzuLog logger = HubzuLog.getLogger( DateUtils.class );

    public static Long getRemainingDays( String date ) {
        Long remainingDays = null;
        if (!StringUtils.isEmpty( date )) {
            SimpleDateFormat formatter = new SimpleDateFormat( LIST_DATE_FORMAT );
            try {
                Date marketDate = formatter.parse( date );
                LocalDateTime marketdateLocal = marketDate.toInstant().atZone( ZoneId.systemDefault() ).toLocalDateTime();
                if (!( 1970 == marketdateLocal.getYear() && 1 == marketdateLocal.getDayOfYear() )) {
                    LocalDateTime presentDate = LocalDateTime.now();
                    remainingDays = Duration.between( marketdateLocal, presentDate ).toDays();
                }
            } catch ( ParseException e ) {
                logger.error( "Error in parsing the date: " + date, e );
            }
        }
        return remainingDays;
    }

}
