package com.zuners.listingsws.pdp.url;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zuners.listingsws.request.PdpUrlRequest;
import com.zuners.listingsws.service.PdpUrlService;

/**
 * The class AddressPdpUrlFetcher
 *
 * @author rajputbh
 *
 */
@Service("addressPdpUrlFetcher")
public class AddressPdpUrlFetcher extends PdpUrlFetcher {
	@Autowired
	private PdpUrlService pdpUrlService;

	@Override
	protected String myGet(PdpUrlRequest pdpUrlRequest) {
	    return pdpUrlService.getPdpAddressString(pdpUrlRequest.getAddressHash());
	}
}
