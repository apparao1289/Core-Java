package com.zuners.listingsws.decorator.impl;

import static com.zuners.listingsws.common.Constants.JSONPATH_ADDRESS_HASH;
import static com.zuners.listingsws.common.Constants.JSONPATH_CITY;
import static com.zuners.listingsws.common.Constants.JSONPATH_STREET_NAME;
import static com.zuners.listingsws.common.Constants.JSONPATH_STREET_NUMBER;
import static com.zuners.listingsws.common.Constants.JSONPATH_STREET_SUFFIX;
import static com.zuners.listingsws.common.Constants.JSONPATH_SUITE_NAME;
import static com.zuners.listingsws.common.Constants.JSONPATH_SUITE_NUMBER;
import static com.zuners.listingsws.common.Constants.JSONPATH_ZIP;
import static com.zuners.listingsws.common.Constants.JSON_TAG_DATA;
import static com.zuners.listingsws.common.Constants.JSON_TAG_PDP_URL;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_KEY;
import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_VALUE;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import com.hubzu.common.logger.HubzuLog;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.zuners.listingsws.common.ApplicationException;
import com.zuners.listingsws.decorator.ResponseDecorator;
import com.zuners.listingsws.pdp.url.PdpUrlFetcher;
import com.zuners.listingsws.request.ListingRequest;
import com.zuners.listingsws.request.PdpUrlRequest;

/**
 * The Class PdpUrlResponseDecorator.
 * 
 * @author rajputbh
 */
@Service
@Order(value = 10)
public class PdpUrlResponseDecorator implements ResponseDecorator {
	private final static HubzuLog LOGGER = HubzuLog.getLogger(PdpUrlResponseDecorator.class);
	
	@Autowired
	@Qualifier("genericPdpUrlFetcher")
	private PdpUrlFetcher genericPdpUrlFetcher;

	@Override
	public String decorate(ListingRequest request, String response) {
		PdpUrlRequest pdpUrlRequest = fetchPdpUrlRequest(response);
		String pdpAddressUrl = null;
		if (pdpUrlRequest != null) {
		    try{
		        pdpAddressUrl = genericPdpUrlFetcher.get(pdpUrlRequest);
		    }catch(ApplicationException ae){
		        LOGGER.error("pdpUrlRequest : {}", pdpUrlRequest, ae);
		    }
        } else {
            LOGGER.error("pdpUrlRequest is null for request : {}", request.toString());
        }
		
        return updateResponse(request, response, pdpAddressUrl);
	}

	private PdpUrlRequest fetchPdpUrlRequest(String jsonResponse) {
        PdpUrlRequest pdpUrlRequest = new PdpUrlRequest();
        pdpUrlRequest.setAddressHash(fetchElement(JSONPATH_ADDRESS_HASH, jsonResponse));
        pdpUrlRequest.setCity(fetchElement(JSONPATH_CITY, jsonResponse));
        pdpUrlRequest.setZip(fetchElement(JSONPATH_ZIP, jsonResponse));
        pdpUrlRequest.setStreetName(fetchElement(JSONPATH_STREET_NAME, jsonResponse));
        pdpUrlRequest.setStreetNumber(fetchElement(JSONPATH_STREET_NUMBER, jsonResponse));
        pdpUrlRequest.setStreetSuffix(fetchElement(JSONPATH_STREET_SUFFIX, jsonResponse));
        pdpUrlRequest.setSuiteNumber(fetchElement(JSONPATH_SUITE_NUMBER, jsonResponse));
        pdpUrlRequest.setSuiteName(fetchElement(JSONPATH_SUITE_NAME, jsonResponse));
        return pdpUrlRequest;
    }
	
	private String fetchElement(String parameter, String jsonResponse) {
        String parameterValue = null;
        Object document = Configuration.defaultConfiguration().jsonProvider().parse(jsonResponse);
        net.minidev.json.JSONArray parameterJsonArrayOfArray = JsonPath.read(document, parameter);
        if (parameterJsonArrayOfArray != null && parameterJsonArrayOfArray.size() > 0) {
            Object parameterValueObject = (Object) parameterJsonArrayOfArray.get(0);
            if (parameterValueObject != null) {
                parameterValue = parameterValueObject.toString().trim();
            }
        }
        return parameterValue;
    }

	private String updateResponse(ListingRequest request, String response, String pdpAddressUrl) {
		// Convert the string to json object
		JSONObject jsonObject = new JSONObject(response);
		/*-- Fetch the data object which should further store the pdp address url */
		JSONArray dataArray = jsonObject.getJSONArray(JSON_TAG_DATA);
		// Create new object for pdp url
		JSONObject pdpUrlObject = new JSONObject();
		// Add => "k": "pdp-address-url"
		pdpUrlObject.put(MLS_PDP_RESPONSE_KEY, JSON_TAG_PDP_URL);
		// Add => "v": ["<pdp-address-url-value>"]
		JSONArray pdpUrlValueArrayObject = new JSONArray();
		pdpUrlValueArrayObject.put(pdpAddressUrl);
		pdpUrlObject.put(MLS_PDP_RESPONSE_VALUE, pdpAddressUrl==null ? JSONObject.NULL : pdpUrlValueArrayObject);
		// Add the pdpUrlObject in outer array object
		dataArray.put(pdpUrlObject);
		LOGGER.info("pdpAddressUrl : {},  addressHash : {}, request : {}", pdpAddressUrl, request.toString());
		return jsonObject.toString();
	}
}
