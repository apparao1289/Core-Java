package com.zuners.listingsws.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SchoolDistrictInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String type;
    private String name;
    private List<GeoCode> perimeter;
    private List<SchoolInfo> schoolList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<GeoCode> getPerimeter() {
        return perimeter;
    }

    public void setPerimeter(List<GeoCode> perimeter) {
        this.perimeter = perimeter;
    }

    public List<SchoolInfo> getSchoolList() {
        return schoolList;
    }

    public void setSchoolList(List<SchoolInfo> schoolList) {
        this.schoolList = schoolList;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "SchoolDistrictInfo [id=" );
        builder.append( id );
        builder.append( ", type=" );
        builder.append( type );
        builder.append( ", name=" );
        builder.append( name );
        builder.append( ", perimeter=" );
        builder.append( perimeter );
        builder.append( ", schoolList=" );
        builder.append( schoolList );
        builder.append( "]" );
        return builder.toString();
    }
    
}
