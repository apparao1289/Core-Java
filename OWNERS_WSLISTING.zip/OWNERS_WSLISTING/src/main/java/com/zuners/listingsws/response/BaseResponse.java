package com.zuners.listingsws.response;

import java.io.Serializable;
import java.util.List;

public class BaseResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<Message> messages;

	private Boolean success;

	public List<Message> getMessages() {
		return messages;
	}

	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}

}
