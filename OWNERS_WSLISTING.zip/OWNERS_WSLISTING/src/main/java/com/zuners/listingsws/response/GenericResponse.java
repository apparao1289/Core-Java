package com.zuners.listingsws.response;

import java.io.Serializable;
@SuppressWarnings("serial")
public class GenericResponse implements Serializable{

    String status;
    String message;

    public String getStatus() {
        return status;
    }

    public void setStatus( String status ) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage( String message ) {
        this.message = message;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "InquiryResponse [status=" );
        builder.append( status );
        builder.append( ", message=" );
        builder.append( message );
        builder.append( "]" );
        return builder.toString();
    }

}
