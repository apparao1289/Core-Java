package com.zuners.listingsws.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.hubzu.search.model.property.PropertyAndListingDetails;
import com.zuners.listingsws.common.ApplicationException;
import com.zuners.listingsws.dao.DynamoDBClient;

/**
 * The Class PropertyServiceImpl.
 * 
 * @author rajputbh
 */
@Service
public class PropertyServiceImpl implements PropertyService {

	private @Value("${hubzu_aws_dynamodb_table_name:wslisting_dev}") String tableName;

	@Resource(name = "hubzuDynamoDBClient")
	private DynamoDBClient hubzuDynamoDBClient;
	
	@Autowired
	private PropertyDrService propertyDrService;

	@Override
	public void add(PropertyAndListingDetails propertyAndListingDetails) {
		String data = null;
		Gson gson = new Gson();
		data = gson.toJson(propertyAndListingDetails);
		hubzuDynamoDBClient.add(tableName, propertyAndListingDetails.getPropertyDetails().getPropertyId(), data);
		propertyDrService.add(propertyAndListingDetails);
	}

	@Override
	public void delete(final String propertyId) {
		hubzuDynamoDBClient.delete(tableName, propertyId);
		propertyDrService.delete(propertyId);
	}

	@Override
	public PropertyAndListingDetails get(final String propertyId) {
		String jsonData = hubzuDynamoDBClient.get(tableName, propertyId);
		Gson gson = new Gson();
		return gson.fromJson(jsonData, PropertyAndListingDetails.class);
	}

	@Override
	public List<PropertyAndListingDetails> get(String[] propertyIdList) {
		if (propertyIdList == null || propertyIdList.length > 25 || propertyIdList.length < 1) {
			throw new ApplicationException("propertyIdList should be greater than 0 and less than 26");
		}
		List<String> dataList = hubzuDynamoDBClient.getDataList(tableName, propertyIdList);
		Gson gson = new Gson();
		List<PropertyAndListingDetails> propertyAndListingDetailsList = new ArrayList<PropertyAndListingDetails>();
		for (String jsonData : dataList) {
			propertyAndListingDetailsList.add(gson.fromJson(jsonData, PropertyAndListingDetails.class));
		}
		return propertyAndListingDetailsList;
	}
}
