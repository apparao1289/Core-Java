package com.zuners.listingsws.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hubzu.common.logger.HubzuLog;
import com.zuners.listingsws.common.Constants;
import com.zuners.listingsws.request.InquiryRequest;
import com.zuners.listingsws.response.GenericResponse;
import com.zuners.listingsws.service.InquiryService;

@Controller
@RequestMapping( "/2015-08-01/listings" )
public class InquiryController {
	private final static HubzuLog logger = HubzuLog.getLogger( InquiryController.class );

    @Autowired
    private InquiryService inquiryService;

    @RequestMapping( value = "inquiry", produces = "application/json;charset=UTF-8", method = RequestMethod.POST )
    @ResponseBody
    public GenericResponse postInquiry( @RequestBody InquiryRequest inquiryRequest ) {
        GenericResponse genericResponse = new GenericResponse();
        try {
            genericResponse = inquiryService.postInquiry( inquiryRequest );
        } catch ( Exception e ) {
            logger.error( "Exception while submitting the Inquiry", e );
            genericResponse.setStatus( Constants.ERROR_RESPONSE );
            genericResponse.setMessage( e.getMessage() );
        }
        return genericResponse;
    }

}
