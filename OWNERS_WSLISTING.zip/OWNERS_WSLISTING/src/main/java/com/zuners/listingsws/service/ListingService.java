package com.zuners.listingsws.service;

import com.zuners.listingsws.domain.Listing;
import com.zuners.listingsws.dto.PropertyDetailsSource;
import com.zuners.listingsws.request.ListingRequest;

public interface ListingService {
	public void add(Listing listing);
	public void delete(String id);
	public String getById(ListingRequest request);
    String getMlsLastUpdatedDate( String mlsId );
	public void add(PropertyDetailsSource propertyDetailsSource);
}
