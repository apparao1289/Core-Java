package com.zuners.listingsws.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Contains property details from MLS engine.
 * 
 * @author patelpaw
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude(Include.NON_NULL)
public class PropertyDetailsSource implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The key. */
    private String key;

    /** The type. */
    private String type;

    /** The photos. */
    private List< PhotoDetails > photos;

    /** The data. */
    private List< PropertyData > data;

    /** The data sets. */
    private List< PropertyDetailsData > dataSets;

    /**
     * Gets the key.
     *
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the key.
     *
     * @param key
     *            the key to set
     */
    public void setKey( String key ) {
        this.key = key;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the type to set
     */
    public void setType( String type ) {
        this.type = type;
    }

    /**
     * Gets the photos.
     *
     * @return the photos
     */
    public List< PhotoDetails > getPhotos() {
        return photos;
    }

    /**
     * Sets the photos.
     *
     * @param photos
     *            the photos to set
     */
    public void setPhotos( List< PhotoDetails > photos ) {
        this.photos = photos;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public List< PropertyData > getData() {
        return data;
    }

    /**
     * Sets the data.
     *
     * @param data
     *            the data to set
     */
    public void setData( List< PropertyData > data ) {
        this.data = data;
    }

    /**
     * Gets the data sets.
     *
     * @return the dataSets
     */
    public List< PropertyDetailsData > getDataSets() {
        return dataSets;
    }

    /**
     * Sets the data sets.
     *
     * @param dataSets
     *            the dataSets to set
     */
    public void setDataSets( List< PropertyDetailsData > dataSets ) {
        this.dataSets = dataSets;
    }
    
    public Map< String, List< String >> getDataMap() {
        Map< String, List< String >> mapData = null;
        if (!CollectionUtils.isEmpty( data )) {
            mapData = new HashMap< String, List< String >>();
            for ( PropertyData propertyData : data ) {
                mapData.put( propertyData.getKey(), propertyData.getValues() );
            }
        }
        return mapData;
    }
    
    public Map< String, List< PropertyDetailsData >> getDataSetMap() {
        Map< String, List< PropertyDetailsData > > mapDataSet = null;
        if (!CollectionUtils.isEmpty( dataSets )) {
            mapDataSet = new HashMap< String, List< PropertyDetailsData > >();
            for ( PropertyDetailsData propertyDetailsData : dataSets ) {
                List< PropertyDetailsData > propertyDetailsDataList = null;
                propertyDetailsDataList = mapDataSet.get( propertyDetailsData.getType() );
                if (CollectionUtils.isEmpty( propertyDetailsDataList )) {
                    propertyDetailsDataList = new ArrayList< PropertyDetailsData >();
                }
                propertyDetailsDataList.add( propertyDetailsData );
                mapDataSet.put( propertyDetailsData.getType(), propertyDetailsDataList );
            }
        }
        return mapDataSet;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "PropertyDetailsSource [key=" );
        builder.append( key );
        builder.append( ", type=" );
        builder.append( type );
        builder.append( ", photos=" );
        builder.append( photos );
        builder.append( ", data=" );
        builder.append( data );
        builder.append( ", dataSets=" );
        builder.append( dataSets );
        builder.append( "]" );
        return builder.toString();
    }  
}
