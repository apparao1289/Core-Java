package com.zuners.listingsws.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hubzu.common.logger.HubzuLog;
import com.zuners.listingsws.common.Constants;
import com.zuners.listingsws.service.ListingService;

@Controller
@RequestMapping( "/board" )
public class BoardController {

    private final static HubzuLog logger = HubzuLog.getLogger( BoardController.class );

    @Autowired
    private ListingService listingService;

    @RequestMapping( "/updatedate/{mlsId}" )
    @ResponseBody
    public String getLastUpdatedDate( @PathVariable String mlsId ) {
        return listingService.getMlsLastUpdatedDate( mlsId );
    }

    @ExceptionHandler( Exception.class )
    @ResponseBody
    public Map< String, String > errorResponse( Exception ex, HttpServletResponse response ) {
        Map< String, String > errorMap = new HashMap< String, String >();
        errorMap.put( "Status", Constants.ERROR_RESPONSE );
        response.setStatus( HttpStatus.INTERNAL_SERVER_ERROR.value() );
        logger.error( "Error ", ex );
        return errorMap;
    }

}
