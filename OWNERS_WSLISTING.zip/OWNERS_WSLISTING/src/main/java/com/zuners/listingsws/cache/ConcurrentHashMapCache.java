package com.zuners.listingsws.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The Class ConcurrentHashMapCache.
 * 
 * @author rajputbh
 */
public class ConcurrentHashMapCache implements Cache {
	Map<Object, Object> cache = null;

	public ConcurrentHashMapCache(int initialCapacity, float loadFactor, int concurrencyLevel) {
		super();
		cache = new ConcurrentHashMap<Object, Object>(initialCapacity, loadFactor, concurrencyLevel);
	}

	public void put(Object key, Object value) {
		if (key != null && value != null) {
			cache.put(key, value);
		}
	}

	public Object get(Object key) {
		return cache.get(key);
	}

	public void evict(Object key) {
		cache.remove(key);
	}

	public void clear() {
		cache.clear();
	}
}
