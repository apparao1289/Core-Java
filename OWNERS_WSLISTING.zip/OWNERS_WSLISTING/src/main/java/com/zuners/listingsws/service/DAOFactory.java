package com.zuners.listingsws.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zuners.listingsws.dao.ListingDAO;

@Service
public class DAOFactory {
	@Resource(name = "mlsListingDAO")
	private ListingDAO mlsListingRepository;
	
	@Resource(name = "fsboListingDAO")
	private ListingDAO fsboListingRepository;
	
	public ListingDAO getDao(String cohort) {
		if (cohort.equalsIgnoreCase("fsbo"))
			return fsboListingRepository;
		else if (cohort.equalsIgnoreCase("mls")) {
			return mlsListingRepository;
		}
		return mlsListingRepository;
	}
}
