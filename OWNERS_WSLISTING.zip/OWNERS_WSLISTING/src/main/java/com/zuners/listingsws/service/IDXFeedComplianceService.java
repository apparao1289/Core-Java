package com.zuners.listingsws.service;

import static com.zuners.listingsws.common.Constants.*;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hubzu.common.logger.HubzuLog;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.zuners.listingsws.common.Constants;
import com.zuners.listingsws.common.JsonUtil;
import com.zuners.listingsws.dao.MlsListingDAO;
import com.zuners.listingsws.util.SearchServiceUtil;

@Service
public class IDXFeedComplianceService {
	private final static HubzuLog LOGGER = HubzuLog.getLogger(IDXFeedComplianceService.class);

	@Autowired
	private MlsListingDAO mlsListingDAO;
	
	@Autowired
	private SearchServiceUtil searchServiceUtil;
	
	@Autowired
	MLSBoardService mlsBoardService;

	public String getIDXFeedDetails(String id, String response) {
		String searchResponse;
		String dynamoResponse = response;
		try {
			String hash = checkIDXValue(dynamoResponse);
			if (hash != null) {
			    String propertyId = null;
				LOGGER.debug("FSBO_MLS_FLAG found " + dynamoResponse.toString());
				searchResponse = searchServiceUtil.searchProperty(hash, Constants.SEARCH_RESPONSE_MAX_COUNT);
				LOGGER.debug("searchResponse : {}", searchResponse);
				Object document = Configuration.defaultConfiguration().jsonProvider().parse(searchResponse);
                for (int i = 0; i < Constants.SEARCH_RESPONSE_MAX_COUNT; i++) {
				    String propertyIndex = Constants.JSONPATH_PROPERTY_ID_DATA_INDEX_ITH.replace("'i'", i+"");
				    String sellerCodeIndex = Constants.JSONPATH_SELLER_CODE_DATA_INDEX_ITH.replace("'i'", i+"");
				    net.minidev.json.JSONArray sellerCodeArray = JsonPath.read(document, sellerCodeIndex);
				    String sellerCode = (String) sellerCodeArray.get(0);
				    LOGGER.debug("Checking for sellerCode : {}", sellerCode);
                    if (StringUtils.isNotBlank(sellerCode) && mlsBoardService.isBoardActive(sellerCode)) {
                        LOGGER.debug("Active sellerCode : {}", sellerCode);
				        net.minidev.json.JSONArray propertyIdArray = JsonPath.read(document, propertyIndex);
	                    propertyId = (String) propertyIdArray.get(0);
                        if (StringUtils.isNotBlank(propertyId)) {
                            LOGGER.debug("Got Property Id : {} for Active sellerCode : {}", propertyId, sellerCode);
	                        break;
	                    }
				    }
				}
                if (StringUtils.isNotBlank(propertyId)) {
					propertyId = propertyId.substring(Constants.SEARCH_RESPONSE_INDEX_ZERO,
							Constants.SEARCH_RESPONSE_DELIMITER_INDEX)
							+ Constants.SEARCH_RESPONSE_DELIMITER + propertyId.substring(
									Constants.SEARCH_RESPONSE_DELIMITER_INDEX, propertyId.length());
					String mlsResponse = mlsListingDAO.getById(propertyId,null);
					if (StringUtils.isNotBlank(mlsResponse)) {
						dynamoResponse = JsonUtil.copyElement(response, mlsResponse, JSON_TAG_TAGS, JSON_TAG_DATA);
						dynamoResponse = JsonUtil.copyElement(response, dynamoResponse, JSON_TAG_CUST_INFO, JSON_TAG_DATA);
						dynamoResponse = JsonUtil.addElement(response, dynamoResponse, JSON_TAG_LINKS);
						dynamoResponse = JsonUtil.replaceElement(response, dynamoResponse, JSON_TAG_PHOTOS);
					}
				}
			}
		} catch (PathNotFoundException e) {
			/**
			 * Kept it intentionally
			 */
			LOGGER.debug("No property found in Search Result : {}", id);
		} catch (Exception e) {
			LOGGER.error("Exception while getting IDX Feed for : {}", id, e);
		}
		return dynamoResponse;
	}

	private String checkIDXValue(String response) {
		String hash = null;
		if (!response.isEmpty()) {
			Object document = Configuration.defaultConfiguration().jsonProvider().parse(response);
			net.minidev.json.JSONArray parameterJsonArrayOfArray = JsonPath.read(document, JSONPATH_TAGS);
			if (checkPropertyType(parameterJsonArrayOfArray)) {
				hash = fetchElement(JSONPATH_ADDRESS_HASH, response);
			}
		}

		return hash;
	}

	private String fetchElement(String parameter, String jsonResponse) {
		String parameterValue = null;
		Object document = Configuration.defaultConfiguration().jsonProvider().parse(jsonResponse);
		net.minidev.json.JSONArray parameterJsonArrayOfArray = JsonPath.read(document, parameter);
		if (parameterJsonArrayOfArray != null && parameterJsonArrayOfArray.size() > 0) {
			Object parameterValueObject = (Object) parameterJsonArrayOfArray.get(0);
			if (parameterValueObject != null) {
				parameterValue = parameterValueObject.toString().trim();
			}
		}
		return parameterValue;
	}

	private boolean checkPropertyType(net.minidev.json.JSONArray jsonArray) {
		if (jsonArray.toString().contains("MLS")) {
			return true;
		}
		return false;
	}

}
