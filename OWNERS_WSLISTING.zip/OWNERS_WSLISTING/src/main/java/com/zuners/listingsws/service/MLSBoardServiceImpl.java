package com.zuners.listingsws.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.hubzu.common.logger.HubzuLog;
import com.hubzu.search.common.constants.ApplicationConstant;
import com.hubzu.search.model.aws.MlsBoards;
import com.zuners.listingsws.util.SearchServiceUtil;

@Service
public class MLSBoardServiceImpl implements MLSBoardService {

    private static final HubzuLog LOGGER = HubzuLog.getLogger(MLSBoardServiceImpl.class);

    @Autowired
    SearchServiceUtil searchServiceUtil;

    List<MlsBoards> mlsBoardDetails;
    Map<String, MlsBoards> mlsBoardsInfoMap = null;

    @PostConstruct
    @Scheduled(fixedDelayString = "${mlsboard_scheduler_delay:300000}")
    public void init() {
        try {
            List<MlsBoards> tempMlsBoards = searchServiceUtil.getBoardDetails();
            if (!CollectionUtils.isEmpty(tempMlsBoards)) {
                Map<String, MlsBoards> tempMap = new HashMap<String, MlsBoards>();
                tempMlsBoards.forEach(board -> {
                    tempMap.put(board.getMlsBoardID(), board);
                });
                mlsBoardDetails = tempMlsBoards;
                mlsBoardsInfoMap = tempMap;
            }
        } catch (Exception e) {
            LOGGER.error("Error while getting Board Information", e);
        }
    }

    @Override
    public MlsBoards getMlsBoard(String key) {
        if (!CollectionUtils.isEmpty(mlsBoardsInfoMap)) {
            if (key.startsWith(ApplicationConstant.TAG_MLS)) {
                key = key.substring(3);
            }
            return mlsBoardsInfoMap.get(key);
        } else {
            return null;
        }
    }

    @Override
    public boolean isBoardActive(String key) {
        if (!CollectionUtils.isEmpty(mlsBoardsInfoMap)) {
            if (key.startsWith(ApplicationConstant.TAG_MLS)) {
                key = key.substring(3);
            }
            MlsBoards mlsBoard = mlsBoardsInfoMap.get(key);
            if (mlsBoard != null) {
                return mlsBoard.getIsActive();
            }
        }
        return false;
    }

}
