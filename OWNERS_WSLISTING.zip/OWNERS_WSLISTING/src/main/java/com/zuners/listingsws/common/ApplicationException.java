package com.zuners.listingsws.common;

public class ApplicationException extends RuntimeException {

	private static final long serialVersionUID = -4362672614749071848L;

	public ApplicationException(String message) {
		super(message);
	}
}
