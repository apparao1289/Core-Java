package com.zuners.listingsws.decorator.impl;

import java.io.IOException;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.hubzu.common.logger.HubzuLog;
import com.zuners.listingsws.common.CommonUtils;
import com.zuners.listingsws.common.Constants;
import com.zuners.listingsws.common.JsonUtil;
import com.zuners.listingsws.dao.OwnersAPIClient;
import com.zuners.listingsws.decorator.ResponseDecorator;
import com.zuners.listingsws.request.ListingRequest;
import com.zuners.listingsws.response.SchoolDistrictInfo;

@Service
@Order( value = 2 )
public class SchoolDistrictResponseDecorator implements ResponseDecorator {

    private static final String SCHOOL_DISTRICT_ATTRIBUTE = "school_district";

    private final static HubzuLog logger = HubzuLog.getLogger( SchoolDistrictResponseDecorator.class );

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    OwnersAPIClient ownersAPIClient;

    @Override
    public String decorate( ListingRequest request, String response ) {
        logger.debug( "Calling School District Response Decorator" );
        if (!StringUtils.isEmpty( response ) && commonUtils.isAdditionalAttribute( SCHOOL_DISTRICT_ATTRIBUTE )) {
            try {
                String schoolDistrictResponse = ownersAPIClient.getSchoolDistrict( commonUtils.getEscapedPropertyId( request.getId() ) );
                logger.debug( "Got Response from search services : {}", schoolDistrictResponse );
                String pdpSchoolDistrictInfo = JsonUtil.getResponseFromJson( schoolDistrictResponse );
                logger.debug( "Got Actual School District Response : {}", pdpSchoolDistrictInfo );
                if (!StringUtils.isEmpty( pdpSchoolDistrictInfo ) && !pdpSchoolDistrictInfo.equalsIgnoreCase( Constants.SEARCH_RESPONSE_UNKNOWN )) {
                    try {
                        SchoolDistrictInfo schoolDistrictInfo = JsonUtil.convertFromJson( pdpSchoolDistrictInfo, SchoolDistrictInfo.class );
                        JSONObject jsonObject = new JSONObject( response );
                        JSONObject schooDistrictJsonObject = new JSONObject( schoolDistrictInfo );
                        jsonObject.put( "schoolDistrict", schooDistrictJsonObject );
                        return jsonObject.toString();
                    } catch ( IOException e ) {
                        logger.error( "Error while json parsing the school district response : {}", pdpSchoolDistrictInfo, e );
                    }
                }
                logger.debug( "Unknown Response from search services so ignoring the same for propertyId: {}", request.getId() );
                JSONObject jsonObject = new JSONObject( response );
                jsonObject.put( "schoolDistrict", JSONObject.NULL );
                return jsonObject.toString();
            } catch ( Exception e ) {
                logger.debug( "No Response from search services so ignoring the same for propertyId: {}", request.getId() );
            }
        }
        return response;
    }

}
