package com.zuners.listingsws.controller;

import java.text.DateFormat;
import java.util.Date;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hubzu.common.logger.HubzuLog;

/**
 * Handles requests for the application home page.
 */
@RestController
public class StatusController {

	private final static HubzuLog logger = HubzuLog.getLogger(StatusController.class);

	@RequestMapping(value = "/", method = RequestMethod.GET)
	@ResponseBody
	public String home() {

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG,
				DateFormat.LONG);

		String message = String.format("Welcome Home! Server time is: %s.", 
				dateFormat.format(date));
		logger.info(message);

		return message;
	}
	

}
