package com.zuners.listingsws.decorator;

import com.zuners.listingsws.request.ListingRequest;

public interface ResponseDecorator {
    
    public String decorate(ListingRequest listingRequest, String response);

}
