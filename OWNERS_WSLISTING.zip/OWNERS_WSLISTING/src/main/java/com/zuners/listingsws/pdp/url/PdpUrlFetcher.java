package com.zuners.listingsws.pdp.url;

import com.zuners.listingsws.common.ApplicationException;
import com.zuners.listingsws.request.PdpUrlRequest;

/**
 * Abstract PdpUrlFetcher Service to get pdp url for given address hash.
 *
 * @author rajputbh
 *
 */
public abstract class PdpUrlFetcher {
	protected PdpUrlFetcher successor;

	public void setSuccessor(PdpUrlFetcher successor) {
		this.successor = successor;
	}
	
	public String get(PdpUrlRequest pdpUrlRequest) {
        if (pdpUrlRequest != null) {
            return myGet(pdpUrlRequest);
        } else {
            throw new ApplicationException("Invalid parameter : parameter is null");
        }
    }

	abstract protected String myGet(PdpUrlRequest pdpUrlRequest);
}
