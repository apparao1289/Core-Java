package com.zuners.listingsws.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zuners.listingsws.dao.OwnersAPIClient;
import com.zuners.listingsws.request.InquiryRequest;
import com.zuners.listingsws.response.GenericResponse;

@Service
public class InquiryServiceImpl implements InquiryService {

    @Autowired
    OwnersAPIClient ownersAPIClient;

    @Override
    public GenericResponse postInquiry( InquiryRequest inquiryRequest ) {
        GenericResponse genericResponse = ownersAPIClient.postInquiry( inquiryRequest );
        return genericResponse;
    }

}
