package com.zuners.listingsws.controller;

import java.util.Date;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hubzu.common.logger.HubzuLog;

/**
 * The Class LbStatusController. This controller is used to check the status of
 * communication between Load Balancer and its underlying nodes.
 * 
 * @author rajputbh
 */
@RestController
public class LbStatusController {
	private final static HubzuLog logger = HubzuLog.getLogger(LbStatusController.class);

    @RequestMapping(value = "/lbstatus", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String checkLbStatus() {
        logger.debug("Load Balancer Status Check Called : {}", new Date(System.currentTimeMillis()));
        return "OK";
    }
}