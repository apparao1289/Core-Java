package com.zuners.listingsws.dto;

public class StateAbbreviationMapping {

    String state;
    String stateName;

    public String getState() {
        return state;
    }

    public void setState( String state ) {
        this.state = state;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName( String stateName ) {
        this.stateName = stateName;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "StateAbbreviationMapping [state=" );
        builder.append( state );
        builder.append( ", stateName=" );
        builder.append( stateName );
        builder.append( "]" );
        return builder.toString();
    }
    
}
