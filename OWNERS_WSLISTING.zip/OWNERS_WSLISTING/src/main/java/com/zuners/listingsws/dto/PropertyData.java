package com.zuners.listingsws.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Contains property data in key and list of values format.
 * 
 * @author patelpaw
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
public class PropertyData implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The key. */
    private String key;

    /** The values. */
    private List< String > values;
    
    private List< PropertyAdditionalData > cv;

    /**
     * Gets the key.
     *
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the key.
     *
     * @param key
     *            the key to set
     */
    public void setKey( String key ) {
        this.key = key;
    }

    /**
     * Gets the values.
     *
     * @return the values
     */
    public List< String > getValues() {
        return values;
    }

    /**
     * Sets the values.
     *
     * @param values
     *            the values to set
     */
    public void setValues( List< String > values ) {
        this.values = values;
    }

    /**
     * @return the cv
     */
    public List< PropertyAdditionalData > getCv() {
        return cv;
    }

    /**
     * @param cv the cv to set
     */
    public void setCv( List< PropertyAdditionalData > cv ) {
        this.cv = cv;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "PropertyData [key=" );
        builder.append( key );
        builder.append( ", values=" );
        builder.append( values );
        builder.append( ", cv=" );
        builder.append( cv );
        builder.append( "]" );
        return builder.toString();
    }

}
