package com.zuners.listingsws.dao;

import javax.annotation.Resource;

import org.apache.http.client.fluent.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriUtils;

import com.hubzu.common.logger.HubzuLog;
import com.zuners.listingsws.common.ApplicationException;
import com.zuners.listingsws.common.RestClientService;
import com.zuners.listingsws.request.InquiryRequest;
import com.zuners.listingsws.response.BaseResponse;
import com.zuners.listingsws.response.GenericResponse;
import com.zuners.listingsws.service.IDXFeedComplianceService;

@Component
@Configuration
public class OwnersAPIClient {

	private static final String OWNERS_API_URL_INQUIRIES = "/inquiries";

	private static final String URL_SEPARATOR = "/";

	private static final String OWNERS_API_URL_LISTINGS = "/listings";

	private static final String OWNERS_API_VERSION = "v1";

	private final static HubzuLog logger = HubzuLog.getLogger(OwnersAPIClient.class);

	private static final String apiErrorMessage = "Owners API failure for ";

	@Resource
	private Environment env;

	@Autowired
	private RestClientService restClientService;

	private @Value("${owners_url}") String url;

	private @Value("${owners_api_url}") String apiUrl;

	private @Value("${owners_getmlslastupdatedtime_api_url}") String getMlsLastUpdatedTimeUrl;

	private @Value("${owners_getpdpvalues_api_url}") String getPdpValues;

	private @Value("${owners_api_connection_timeout}") int connectTimeout;

	private @Value("${owners_api_socket_timeout}") int socketTimeout;

	private @Value("${search_url}") String searchUrl;

	private @Value("${wsbuyer_url}") String wsbuyerUrl;

	private @Value("${search_school_district_api_url}") String schoolDistrictApiUrl;

	private @Value("${wsbuyer_userfavorite_api_url}") String userFavoriteApiUrl;

	private @Value("${idx_feed.compliance:false}") boolean idxFeedCompliance;

	@Autowired
	IDXFeedComplianceService complianceService;

	public String getById(String id) {
		String urlToBeHit = apiUrl + OWNERS_API_VERSION + OWNERS_API_URL_LISTINGS + URL_SEPARATOR + id;
		logger.debug("Owners url to be hit : {}", urlToBeHit);
		String response = null;
		try {
			response = getResponse(urlToBeHit);
			if (idxFeedCompliance) {
				response = complianceService.getIDXFeedDetails(id, response);
			}
		} catch (Exception e) {
			response = e.getMessage();
		}
		return response;
	}

	/*
	 * Not Used Anymore
	 */
	public String getMlsLastUpdatedDate(String mapSetId) {
		String urlToBeHit = url + getMlsLastUpdatedTimeUrl + "?mapsetid=" + mapSetId;
		logger.debug("Owners url to be hit : {}", urlToBeHit);
		return getResponse(urlToBeHit);
	}

	public String getPdpValues(String mapSetId, String state, String listingAgentBrokerage) {
		String urlToBeHit = url + getPdpValues + "?mapsetid=" + mapSetId + "&state=" + state + "&listingagentbrokerage="
				+ listingAgentBrokerage;
		logger.debug("Owners url to be hit : {}", urlToBeHit);
		return getResponse(urlToBeHit);
	}

	public String getUserFavorite(String propertyId, String userId) {
		String urlToBeHit = wsbuyerUrl + userFavoriteApiUrl + URL_SEPARATOR + propertyId + URL_SEPARATOR + userId;
		logger.debug("wsbuyer url to be hit : {}", urlToBeHit);
		return getResponse(urlToBeHit);
	}

	public String getSchoolDistrict(String propertyId) {
		String urlToBeHit = searchUrl + schoolDistrictApiUrl + URL_SEPARATOR + propertyId;
		logger.debug("mapsearch url to be hit : {}", urlToBeHit);
		return getResponse(urlToBeHit);
	}

	/*
	 * In case of listing not present: http://integ.api.owners.com/v1/inquiries
	 * In case of listing present:
	 * http://integ.api.owners.com/v1/listings/{listingId}/contact
	 */
	public GenericResponse postInquiry(InquiryRequest inquiryRequest) {
		String urlToBeHit = null;
		if (StringUtils.isEmpty(inquiryRequest.getListingId())) {
			urlToBeHit = apiUrl + OWNERS_API_VERSION + OWNERS_API_URL_INQUIRIES;
		} else {
			urlToBeHit = apiUrl + OWNERS_API_VERSION + OWNERS_API_URL_LISTINGS + URL_SEPARATOR
					+ inquiryRequest.getListingId() + "/contact";
		}
		logger.debug(".Net api url to be hit : {}", urlToBeHit);
		BaseResponse baseResponse = restClientService.postEntity(urlToBeHit, inquiryRequest,
				BaseResponse.class);
		
		logger.debug("Response for url : {} is {}", urlToBeHit, baseResponse);
		
		GenericResponse genericResponse = new GenericResponse();
		if(null != baseResponse) {
			genericResponse.setStatus(null != baseResponse.getSuccess() ? baseResponse.getSuccess().toString() : null);
			genericResponse.setMessage(!CollectionUtils.isEmpty(baseResponse.getMessages()) ? baseResponse.getMessages().get(0).getMessage() : null);
		}
		return genericResponse;
	}

	public String getResponse(String url) {
		String response = "";
		try {
			response = Request.Get(UriUtils.encodeFragment(url, "utf-8")).connectTimeout(connectTimeout)
					.socketTimeout(socketTimeout).addHeader("Accept", "application/json").execute().returnContent()
					.asString();
		} catch (Exception e) {
			String errorMessage = apiErrorMessage + url;
			logger.error(errorMessage, e);
			throw new ApplicationException(errorMessage);
		}
		return response;

	}

}
