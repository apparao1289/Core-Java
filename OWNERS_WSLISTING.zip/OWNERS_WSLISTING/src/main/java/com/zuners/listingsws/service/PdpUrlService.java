package com.zuners.listingsws.service;

import org.springframework.stereotype.Service;

import com.hubzu.search.model.property.PropertyAddress;
import com.zuner.addrserv.model.common.Address;
import com.zuner.addrserv.model.response.NormalisedAddress;

/**
 * The Interface PdpUrlService.
 * 
 * @author rajputbh
 */
@Service
public interface PdpUrlService {
    public String getPdpAddressString(final String normalisedAddressHash);

    public String getPdpAddressString(NormalisedAddress normalisedAddress);

    public String getPdpAddressString(final Address address);

    public String getPdpAddressString(final PropertyAddress propertyAddress);
}
