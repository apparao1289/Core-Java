package com.zuners.listingsws.cache;

/**
 * The interface Cache.
 * 
 * @author rajputbh
 */
public interface Cache {
	public void put(Object key, Object value);

	public Object get(Object key);

	public void evict(Object key);

	public void clear();
}
