package com.zuners.listingsws.service;

import com.zuners.listingsws.request.InquiryRequest;
import com.zuners.listingsws.response.GenericResponse;

public interface InquiryService {

    public GenericResponse postInquiry( InquiryRequest inquiryRequest );

}
