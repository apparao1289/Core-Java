package com.zuners.listingsws.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Response body for APIs response to be delivered from APIs. To be used by
 * every responseBody in the controller to support the uniform response
 * structure.
 *
 * @author singsanj
 * @version 1.0
 *
 * @param <T>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Response<T> extends BaseResponse {

	private T result;

	/**
	 * @return the result
	 */
	public T getResult() {
		return result;
	}

	/**
	 * @param result
	 *            the result to set
	 */
	public void setResult(T result) {
		this.result = result;
	}

}
