package com.zuners.listingsws.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hubzu.common.logger.HubzuLog;
import com.hubzu.search.model.property.PropertyAddress;
import com.zuner.addrserv.model.common.Address;
import com.zuner.addrserv.model.response.NormalisedAddress;
import com.zuners.listingsws.dto.BaseResponse.Status;
import com.zuners.listingsws.dto.Response;
import com.zuners.listingsws.pdp.url.CachePdpUrlFetcher;
import com.zuners.listingsws.pdp.url.PdpUrlFetcher;
import com.zuners.listingsws.request.PdpUrlRequest;
import com.zuners.listingsws.service.PdpUrlService;
import com.zuners.listingsws.util.JsonUtil;

/**
 * The Class PdpUrlController.
 * 
 * @author rajputbh
 */
@RestController
@RequestMapping("/2015-08-01/pdp_url_path")
public class PdpUrlController {

	private final static HubzuLog logger = HubzuLog.getLogger(PdpUrlController.class);

	@Autowired
	private PdpUrlService pdpUrlService;
	@Autowired
	private CachePdpUrlFetcher cachePdpUrlFetcher;
	@Autowired
	private PdpUrlFetcher genericPdpUrlFetcher;

	@RequestMapping(value = "/{normalisedAddressHash}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> getPdpAddressString(@PathVariable final String normalisedAddressHash) {
		Response<String> response = new Response<String>();
		try {
		    PdpUrlRequest pdpUrlRequest = new PdpUrlRequest();
		    pdpUrlRequest.setAddressHash(normalisedAddressHash);
			response.setResult(genericPdpUrlFetcher.get(pdpUrlRequest));
		} catch (Exception e) {
			logger.error("normalisedAddressHash : {}", normalisedAddressHash, e);
			response.setStatus(Status.FAILURE);
			response.setMessage(e.getMessage());
		}
		return response;
	}

	@RequestMapping(value = "/normalised_addr", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> getPdpAddressString(@RequestBody NormalisedAddress normalisedAddress) {
		Response<String> response = new Response<String>();
		try {
			response.setResult(pdpUrlService.getPdpAddressString(normalisedAddress));
		} catch (Exception e) {
			logger.error("normalisedAddress : {}", JsonUtil.toJsonString(normalisedAddress), e);
			response.setStatus(Status.FAILURE);
			response.setMessage(e.getMessage());
		}
		return response;
	}

	@RequestMapping(value = "/normal_addr", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> getPdpAddressString(@RequestBody final Address address) {
		Response<String> response = new Response<String>();
		try {
			response.setResult(pdpUrlService.getPdpAddressString(address));
		} catch (Exception e) {
			logger.error("address : {}", address, e);
			response.setStatus(Status.FAILURE);
			response.setMessage(e.getMessage());
		}
		return response;
	}

	@RequestMapping(value = "/property_addr", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> getPdpAddressString(@RequestBody final PropertyAddress propertyAddress) {
		Response<String> response = new Response<String>();
		try {
			response.setResult(pdpUrlService.getPdpAddressString(propertyAddress));
		} catch (Exception e) {
			logger.error("address : {}", propertyAddress, e);
			response.setStatus(Status.FAILURE);
			response.setMessage(e.getMessage());
		}
		return response;
	}

	@RequestMapping(value = "/clear_cache", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> evictCache() {
		Response<String> response = new Response<String>();
		try {
			cachePdpUrlFetcher.evict();
			response.setResult(Status.SUCCESS.name());
		} catch (Exception e) {
			logger.error("Evict Cache Exception", e);
			response.setStatus(Status.FAILURE);
			response.setMessage(e.getMessage());
		}
		return response;
	}
}
