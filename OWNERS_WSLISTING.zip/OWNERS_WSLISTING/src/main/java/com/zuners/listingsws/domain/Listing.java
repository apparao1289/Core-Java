package com.zuners.listingsws.domain;

import java.io.Serializable;

public class Listing implements Serializable{

	private static final long serialVersionUID = -519581537573245094L;

	private String id;
	
	private String document;

	public Listing() {
	}

	public Listing(String id, String document) {
		this.id = id;
		this.document = document;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	@Override
	public String toString() {
		return "Listing [Id=" + id + ", price =" + document + "]";
	}

}