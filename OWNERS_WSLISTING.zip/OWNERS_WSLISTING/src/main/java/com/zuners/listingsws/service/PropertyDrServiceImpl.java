package com.zuners.listingsws.service;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.hubzu.search.model.property.PropertyAndListingDetails;
import com.zuners.listingsws.dao.DynamoDBClient;

/**
 * The Class PropertyDrServiceImpl.
 * 
 * @author parakhsh
 */
@Service
public class PropertyDrServiceImpl implements PropertyDrService {

    private @Value("${hubzu_dr_aws_dynamodb_table_name:wslisting_dev}") String tableName;

    @Resource(name = "hubzuDrDynamoDBClient")
    private DynamoDBClient hubzuDrDynamoDBClient;

    @Override
    @Async("drThreadPoolTaskExecutor")
    public void add(PropertyAndListingDetails propertyAndListingDetails) {
        if (hubzuDrDynamoDBClient != null) {
            String data = null;
            Gson gson = new Gson();
            data = gson.toJson(propertyAndListingDetails);
            hubzuDrDynamoDBClient.add(tableName,
                    propertyAndListingDetails.getPropertyDetails().getPropertyId(), data);
        }
    }

    @Override
    @Async("drThreadPoolTaskExecutor")
    public void delete(final String propertyId) {
        if (hubzuDrDynamoDBClient != null) {
            hubzuDrDynamoDBClient.delete(tableName, propertyId);
        }
    }

}
