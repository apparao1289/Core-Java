package com.zuners.listingsws.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Contains additional information of particular property data.
 * 
 * @author patelpaw
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
public class PropertyAdditionalData implements Serializable {

    private static final long serialVersionUID = 1L;

    private String r;

    private List< String > s;

    private List< String > c;

    /**
     * @return the r
     */
    public String getR() {
        return r;
    }

    /**
     * @param r
     *            the r to set
     */
    public void setR( String r ) {
        this.r = r;
    }

    /**
     * @return the s
     */
    public List< String > getS() {
        return s;
    }

    /**
     * @param s
     *            the s to set
     */
    public void setS( List< String > s ) {
        this.s = s;
    }

    /**
     * @return the c
     */
    public List< String > getC() {
        return c;
    }

    /**
     * @param c
     *            the c to set
     */
    public void setC( List< String > c ) {
        this.c = c;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "PropertyAdditionalData [r=" );
        builder.append( r );
        builder.append( ", s=" );
        builder.append( s );
        builder.append( ", c=" );
        builder.append( c );
        builder.append( "]" );
        return builder.toString();
    }
    
}
