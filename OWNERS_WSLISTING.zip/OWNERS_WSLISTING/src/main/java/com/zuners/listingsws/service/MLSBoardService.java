package com.zuners.listingsws.service;

import com.hubzu.search.model.aws.MlsBoards;

public interface MLSBoardService {

    MlsBoards getMlsBoard(String key);

    boolean isBoardActive(String key);

}
