package com.zuners.listingsws.service;

import java.io.Serializable;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hubzu.common.cache.CacheManager;
import com.hubzu.common.cache.config.CacheConfig;
import com.hubzu.common.cache.service.CacheService;
import com.hubzu.common.logger.HubzuLog;

@Service
public class ListingCacheServiceImpl implements ListingCacheService {

    /** The Constant LOGGER. */
    private static final HubzuLog LOGGER = HubzuLog.getLogger(ListingCacheServiceImpl.class);

    /** The cache service. */
    CacheService cacheService;

    private @Value("${listingws_redis.host}") String hostName;
    private @Value("${listingws_redis.password}") String password;
    private @Value("${listingws_redis.port}") int port;
    private @Value("${listingws_redis.timeout}") int timeout = 8000;
    private @Value("${listingws_redis.database}") int database = -1;
    private @Value("${listingws_redis.pool_enable:true}") boolean isPoolEnabled;
    private @Value("${listingws_redis.pool_maxIdle:8}") int redisPoolMaxIdle;
    private @Value("${listingws_redis.pool_minIdle:0}") int redisPoolMinIdle;
    private @Value("${listingws_redis.pool_maxTotal:8}") int redisPoolMaxTotal;
    private @Value("${listingws_redis.pool_maxWait:-1}") int redisPoolMaxWait;

    /**
     * Initialize cache.
     */
    @PostConstruct
    public void initializeCache() {
        LOGGER.debug("Initializing cache");
        CacheConfig cacheConfig = new CacheConfig(hostName, password, port, timeout, database, isPoolEnabled);
        if (isPoolEnabled) {
            cacheConfig.setPoolMaxTotal(redisPoolMaxTotal);
            cacheConfig.setPoolMaxIdle(redisPoolMaxIdle);
            cacheConfig.setPoolMinIdle(redisPoolMinIdle);
            cacheConfig.setPoolMaxWait(redisPoolMaxWait);
        }
        cacheService = CacheManager.getCacheService(cacheConfig);
    }

    @Override
    public void put(String key, Serializable value) {
        LOGGER.debug("Caching with key:{}  value:{}", key, value);
        cacheService.put(key, value);
    }

    @Override
    public Object get(String key) {
        return cacheService.get(key);
    }

    @Override
    public void deleteAll() {
        LOGGER.debug("Deleting all keys");
        cacheService.deleteAll();
    }
}
