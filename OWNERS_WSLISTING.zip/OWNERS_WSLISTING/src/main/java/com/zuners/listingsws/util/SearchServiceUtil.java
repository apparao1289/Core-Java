package com.zuners.listingsws.util;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.fluent.Request;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.util.UriUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.hubzu.common.logger.HubzuLog;
import com.hubzu.search.model.aws.MlsBoards;
import com.hubzu.search.model.response.Response;
import com.zuners.listingsws.common.ApplicationException;

@Service
public class SearchServiceUtil {

    private final static HubzuLog LOGGER = HubzuLog.getLogger(SearchServiceUtil.class);

    private @Value("${search_url}") String searchUrl;

    private @Value("${search_map.search_api_url:api/mapsearch}") String mapSearchUri;

    private @Value("${search_map.board_api_url:api/boards}") String boardUri;

    private String returnValue = "property_id,property_score,tag,seller_code";

    private String filterCriteria = "&sort=property_score desc&fqn.tag=OWNERS&fq.tag=MLS";

    private static final String apiErrorMessage = "Owners API failure for ";

    private @Value("${owners_api_connection_timeout}") int connectTimeout;

    private @Value("${owners_api_socket_timeout}") int socketTimeout;

    public List<MlsBoards> getBoardDetails() {
        String response = getBoardDetailsResponse();
        if (StringUtils.isNotBlank(response)) {
            TypeReference<Response<List<MlsBoards>>> mapType = new TypeReference<Response<List<MlsBoards>>>() {
            };
            Response<List<MlsBoards>> mlsBoardInfo = JsonUtil.toObject(response, mapType);
            if (!CollectionUtils.isEmpty(mlsBoardInfo.getResult())) {
                LOGGER.debug("Board information : {}", mlsBoardInfo.getResult());
                return mlsBoardInfo.getResult();
            }
        }
        LOGGER.error("No Board Information found");
        return null;
    }

    public String getBoardDetailsResponse() {
        String urlToBeHit = searchUrl + "/" + boardUri;
        LOGGER.debug("board url to be hit : {}", urlToBeHit);
        String response = getResponse(urlToBeHit);
        return response;
    }

    public String searchProperty(String hashId, int size) {
        String urlToBeHit = searchUrl + "/" + mapSearchUri + "?searchTerm=*"
                + "&field.normalised_address_hash=" + hashId + "&size=" + size + filterCriteria
                + "&return=" + returnValue;
        LOGGER.debug("searchProperty url to be hit : {}", urlToBeHit);
        return getResponse(urlToBeHit);
    }

    private String getResponse(String url) {
        String response = "";
        try {
            response = Request.Get(UriUtils.encodeFragment(url, "utf-8"))
                    .connectTimeout(connectTimeout).socketTimeout(socketTimeout)
                    .addHeader("Accept", "application/json").execute().returnContent().asString();
        } catch (Exception e) {
            String errorMessage = apiErrorMessage + url;
            LOGGER.error(errorMessage, e);
            throw new ApplicationException(errorMessage);
        }
        return response;

    }

}
