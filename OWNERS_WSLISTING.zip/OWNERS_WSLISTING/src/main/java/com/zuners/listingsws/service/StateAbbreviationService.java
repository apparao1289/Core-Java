package com.zuners.listingsws.service;

public interface StateAbbreviationService {

    String getStateAbbreviation( String stateName );

}
