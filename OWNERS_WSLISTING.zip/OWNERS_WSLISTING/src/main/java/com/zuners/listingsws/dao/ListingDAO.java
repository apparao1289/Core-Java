package com.zuners.listingsws.dao;

import com.zuners.listingsws.domain.Listing;
import com.zuners.listingsws.dto.PropertyDetailsSource;

public interface ListingDAO {
	
	public void delete(String id);
	
	public String getById(String id,String version);
	
	void add(Listing listing);
	
    String getMlsLastUpdatedDate( String boardId );
    
    void add(PropertyDetailsSource propertyDetailsSource);
}
