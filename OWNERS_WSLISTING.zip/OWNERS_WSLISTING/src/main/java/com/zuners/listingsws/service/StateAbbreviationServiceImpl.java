package com.zuners.listingsws.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hubzu.common.logger.HubzuLog;
import com.zuners.listingsws.dto.StateAbbreviationMapping;

@Service
public class StateAbbreviationServiceImpl implements StateAbbreviationService {

	private final static HubzuLog logger = HubzuLog.getLogger( StateAbbreviationServiceImpl.class );

    private static final String WSLISTING_STATE_ABBREVIATION = "listings_state_abbreviation.json";

    Map< String, String > stateMapping = new HashMap< >();

    @PostConstruct
    public void init() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            List< StateAbbreviationMapping > listOfStateAbbreviations = objectMapper.readValue(
                    StateAbbreviationServiceImpl.class.getClassLoader().getResourceAsStream( WSLISTING_STATE_ABBREVIATION ),
                    new TypeReference< List< StateAbbreviationMapping > >() {
                    } );
            for ( StateAbbreviationMapping stateAbbreviationMapping : listOfStateAbbreviations ) {
                stateMapping.put( stateAbbreviationMapping.getStateName().toUpperCase(), stateAbbreviationMapping.getState().toUpperCase() );
            }
        } catch ( Exception e ) {
            logger.error( "Error while getting state mapping", e );
        }

    }

    @Override
    public String getStateAbbreviation( String stateName ) {
        String state = null;
        if (stateName != null && stateName.trim().length() > 0) {
            state = stateMapping.get( stateName.toUpperCase() );
            if (state == null) {
                state = stateName;
                logger.debug( "Returning same state as could not find in json : {}", state);
            }
        }
        logger.debug( "Abbreviation for state : {} is {}", stateName, state );
        return state;
    }

}
