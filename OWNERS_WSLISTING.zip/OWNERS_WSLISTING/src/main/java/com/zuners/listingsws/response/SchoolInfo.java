package com.zuners.listingsws.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SchoolInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String type;
    private String name;
    private GeoCode coordinates;
    private double distance;
    private List<String> gradeList;
    private String rating;
    private String totalStudents;
    private String totalTeachers;
    private String studentTeacherRatio;
    private String address;
    private String city;
    private String state;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public GeoCode getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(GeoCode coordinates) {
        this.coordinates = coordinates;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public List<String> getGradeList() {
        return gradeList;
    }

    public void setGradeList(List<String> gradeList) {
        this.gradeList = gradeList;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getTotalStudents() {
        return totalStudents;
    }

    public void setTotalStudents(String totalStudents) {
        this.totalStudents = totalStudents;
    }

    public String getTotalTeachers() {
        return totalTeachers;
    }

    public void setTotalTeachers(String totalTeachers) {
        this.totalTeachers = totalTeachers;
    }

    public String getStudentTeacherRatio() {
        return studentTeacherRatio;
    }

    public void setStudentTeacherRatio(String studentTeacherRatio) {
        this.studentTeacherRatio = studentTeacherRatio;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "SchoolInfo [id=" );
        builder.append( id );
        builder.append( ", type=" );
        builder.append( type );
        builder.append( ", name=" );
        builder.append( name );
        builder.append( ", coordinates=" );
        builder.append( coordinates );
        builder.append( ", distance=" );
        builder.append( distance );
        builder.append( ", gradeList=" );
        builder.append( gradeList );
        builder.append( ", rating=" );
        builder.append( rating );
        builder.append( ", totalStudents=" );
        builder.append( totalStudents );
        builder.append( ", totalTeachers=" );
        builder.append( totalTeachers );
        builder.append( ", studentTeacherRatio=" );
        builder.append( studentTeacherRatio );
        builder.append( ", address=" );
        builder.append( address );
        builder.append( ", city=" );
        builder.append( city );
        builder.append( ", state=" );
        builder.append( state );
        builder.append( "]" );
        return builder.toString();
    }
    
}
