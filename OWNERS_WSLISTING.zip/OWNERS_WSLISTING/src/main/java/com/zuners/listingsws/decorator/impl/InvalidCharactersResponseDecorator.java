package com.zuners.listingsws.decorator.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import com.hubzu.common.logger.HubzuLog;
import com.zuners.listingsws.common.CommonUtils;
import com.zuners.listingsws.decorator.ResponseDecorator;
import com.zuners.listingsws.request.ListingRequest;

@Service
@Order( value = Ordered.LOWEST_PRECEDENCE)
public class InvalidCharactersResponseDecorator implements ResponseDecorator {
    
	private final static HubzuLog logger = HubzuLog.getLogger(InvalidCharactersResponseDecorator.class);
    
    @Autowired
    CommonUtils commonUtils;

    @Override
    public String decorate( ListingRequest request, String response ) {
        logger.debug( "Calling Invalid Character Response Decorator" );
        return commonUtils.removeUnwantedCharacters( response );
    }

}
