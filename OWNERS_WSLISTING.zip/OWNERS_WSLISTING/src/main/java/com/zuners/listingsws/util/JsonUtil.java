/**
 *
 */
package com.zuners.listingsws.util;

import java.io.IOException;

import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zuners.listingsws.common.ApplicationException;

/**
 * Provides utility method for Object to Json conversion.
 *
 * @author sanketg
 *
 */
public final class JsonUtil {

	/**
	 * Private Constructor.
	 */
	private JsonUtil() {
	}

	/**
	 * This converts Object of type E to its JSON form.
	 *
	 * @param type
	 *            - The type of Object.
	 *
	 * @return - JSON String.
	 */
	public static <E> String toJson(final E type) {
		final String jsonValue = toJsonString(type);

		return jsonValue == null ? null : "[" + jsonValue + "]";

	}

	/**
	 * This converts JSON to Object of type E.
	 *
	 * @param responseEntity
	 *            - Instance of {@link ResponseEntity}.
	 * @param clazz
	 *            - instance of {@link Class}.
	 *
	 * @return - Object of type E.
	 */
	public static <E> Object toObject(final ResponseEntity<String> responseEntity, final Class<E> clazz) {

		E object = toObject(responseEntity.getBody(), clazz);

		return object == null ? null : object;

	}
	
	public static <E> E toObject(final String jsonString, final TypeReference<E> classType) {
        E object = null;
        final ObjectMapper propertyMapper = new ObjectMapper();
        propertyMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
            object = propertyMapper.readValue(jsonString, classType);
        } catch (IOException exception) {
            final String errorMsg = "Json to Object transformation failed: " + jsonString;
            throw new ApplicationException(errorMsg);
        }
        return object;
    }

	/**
	 * This converts JSON to Object of type E.
	 *
	 * @param jsonString
	 *            - String to be converted to JSON.
	 * @param clazz
	 *            - instance of {@link Class}.
	 *
	 * @return - Object of type E.
	 */
	public static <E> E toObject(final String jsonString, final Class<E> clazz) {

		E object = null;
		final ObjectMapper propertyMapper = new ObjectMapper();
		propertyMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			object = propertyMapper.readValue(jsonString, clazz);
		} catch (IOException exception) {
			final String errorMsg = "Json to Object transformation failed: " + jsonString;
			throw new ApplicationException(errorMsg);
		}
		return object;
	}

	/**
	 * This converts Object of type E to its JSON string.
	 *
	 * @param type
	 *            - The type of Object.
	 *
	 * @return - JSON String.
	 */
	public static <E> String toJsonString(final E type) {
		final E object = type;
		String jsonValue = null;
		if (object != null) {
			try {
				final ObjectMapper propertyMapper = new ObjectMapper();
				propertyMapper.setSerializationInclusion(Include.NON_NULL);
				jsonValue = propertyMapper.writeValueAsString(object);
			} catch (IOException exception) {
				final String errorMsg = "Object to Json transformation failed : " + object.toString();
				throw new ApplicationException(errorMsg);
			}
		}
		return jsonValue;
	}

}
