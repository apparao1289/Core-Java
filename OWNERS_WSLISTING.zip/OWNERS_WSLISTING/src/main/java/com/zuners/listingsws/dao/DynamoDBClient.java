package com.zuners.listingsws.dao;

import static com.zuners.listingsws.common.Constants.DYNAMO_DB_DOCUMENT;
import static com.zuners.listingsws.common.Constants.DYNAMO_DB_KEY;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PreDestroy;

import com.amazonaws.services.dynamodbv2.document.BatchGetItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DeleteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.KeyAttribute;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.TableKeysAndAttributes;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;
import com.amazonaws.services.dynamodbv2.model.KeysAndAttributes;
import com.hubzu.common.logger.HubzuLog;

public class DynamoDBClient {

	private DynamoDB dynamoDB = null;
	private final static HubzuLog logger = HubzuLog.getLogger(DynamoDBClient.class);

	public DynamoDBClient(DynamoDB dynamoDB) {
		this.dynamoDB = dynamoDB;
	}

	@PreDestroy
	public void destroy() {
		try {
			com.amazonaws.http.IdleConnectionReaper.shutdown();
		} catch (Exception e) {
			// Left blank intentionally
		}
	}

	public Table getTable(String tableName) {
		return dynamoDB.getTable(tableName);
	}

	public String get(String tableName, String id) {
		Table table = getTable(tableName);
		if (table != null) {
			GetItemSpec spec = new GetItemSpec().withPrimaryKey(DYNAMO_DB_KEY, id).withConsistentRead(true);
			Item item = table.getItem(spec);
			if (item != null) {
				return item.getString(DYNAMO_DB_DOCUMENT);
			}
		}
		return null;
	}

	public List<String> getDataList(String tableName, String[] idList) {
		List<String> listData = null;
		Table table = getTable(tableName);
		if (table != null) {
			TableKeysAndAttributes forumTableKeysAndAttributes = new TableKeysAndAttributes(tableName)
					.withConsistentRead(true);
			forumTableKeysAndAttributes.addHashOnlyPrimaryKeys(DYNAMO_DB_KEY, idList);
			BatchGetItemOutcome batchGetItemOutcome = dynamoDB.batchGetItem(forumTableKeysAndAttributes);
			listData = getDataList(batchGetItemOutcome);
		}
		return listData;
	}

	private List<String> getDataList(BatchGetItemOutcome batchGetItemOutcome) {
		List<String> dataList = new ArrayList<String>();
		Map<String, KeysAndAttributes> unprocessed = null;
		do {
			for (String tableNameFetched : batchGetItemOutcome.getTableItems().keySet()) {
				logger.info("Items in table : {}", tableNameFetched);
				List<Item> items = batchGetItemOutcome.getTableItems().get(tableNameFetched);
				for (Item item : items) {
					dataList.add(item.getString(DYNAMO_DB_DOCUMENT));
					logger.info(item.toJSONPretty());
				}
			}
			// Check for unprocessed keys which could happen if you exceed
			// provisioned throughput or reach the limit on response size.
			unprocessed = batchGetItemOutcome.getUnprocessedKeys();
			if (unprocessed.isEmpty()) {
				logger.info("No unprocessed keys found");
			} else {
				logger.info("Retrieving the unprocessed keys");
				batchGetItemOutcome = dynamoDB.batchGetItemUnprocessed(unprocessed);
			}
		} while (!unprocessed.isEmpty());
		return dataList;
	}

	public void add(String tableName, String id, String data) {
		Table table = getTable(tableName);
		Item item = new Item().withPrimaryKey(DYNAMO_DB_KEY, id).withString(DYNAMO_DB_DOCUMENT, data);
		PutItemOutcome putItemOutcome = table.putItem(item);
		logger.info("putItemOutcome Result: {}", putItemOutcome.getPutItemResult());
	}

	public void delete(String tableName, String id) {
		Table table = getTable(tableName);
		KeyAttribute primaryKey = new KeyAttribute(DYNAMO_DB_KEY, id);
		DeleteItemOutcome deleteItemOutcome = table.deleteItem(primaryKey);
		logger.info("deleteItemOutcome Result: {}", deleteItemOutcome.getDeleteItemResult());
	}
}