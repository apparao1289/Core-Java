package com.zuners.listingsws.pdp.url;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.hubzu.common.logger.HubzuLog;
import com.zuners.listingsws.request.PdpUrlRequest;
import com.zuners.listingsws.service.ListingCacheService;

/**
 * The class CachePdpUrlFetcher
 *
 * @author rajputbh
 *
 */
@Service("cachePdpUrlFetcher")
public class CachePdpUrlFetcher extends PdpUrlFetcher {

    private static final HubzuLog LOGGER = HubzuLog.getLogger(CachePdpUrlFetcher.class);

    private static final String PDP_URL_CACHE = "pdpurlcache";

    private static final String PDP_URL_CACHE_SEPARATOR = "|";

    @Autowired
    private ListingCacheService listingCacheService;

    @Override
    protected String myGet(PdpUrlRequest pdpUrlRequest) {
        String urlString = null;
        String addressHash = pdpUrlRequest.getAddressHash();
        Object url = StringUtils.hasText(addressHash) ? listingCacheService.get(PDP_URL_CACHE + PDP_URL_CACHE_SEPARATOR
                + addressHash) : null;
        if (url != null) {
            urlString = url.toString();
        } else {
            LOGGER.info("Data not found in cache. Calling successor ...");
            urlString = successor.get(pdpUrlRequest);
            if (StringUtils.hasText(urlString) && StringUtils.hasText(addressHash)) {
                listingCacheService.put(PDP_URL_CACHE + PDP_URL_CACHE_SEPARATOR + addressHash, urlString);
            }
        }
        return urlString;
    }

    public void evict() {
        listingCacheService.deleteAll();
    }
}
