package com.zuners.listingsws.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("serial")
@JsonIgnoreProperties(ignoreUnknown = true)
public class MlsPdpResponse implements Serializable{

    String lastUpdatedDate;
    boolean isRebateAvailable;

    @JsonProperty( "LastUpdatedDate" )
    public String getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate( String lastUpdatedDate ) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    @JsonProperty( "IsRebateAvailable" )
    public boolean isRebateAvailable() {
        return isRebateAvailable;
    }

    public void setRebateAvailable( boolean isRebateAvailable ) {
        this.isRebateAvailable = isRebateAvailable;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "MlsPdpResponse [lastUpdatedDate=" );
        builder.append( lastUpdatedDate );
        builder.append( ", isRebateAvailable=" );
        builder.append( isRebateAvailable );
        builder.append( "]" );
        return builder.toString();
    }

}
