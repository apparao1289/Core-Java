package com.zuners.listingsws.pdp.url;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.zuners.listingsws.request.PdpUrlRequest;

/**
 * The class GenericPdpUrlFetcher
 *
 * @author rajputbh
 *
 */
@Service("genericPdpUrlFetcher")
public class GenericPdpUrlFetcher extends PdpUrlFetcher {
	@Autowired
	@Qualifier("addressPdpUrlFetcher")
	private PdpUrlFetcher addressPdpUrlFetcher;
	@Autowired
	@Qualifier("cachePdpUrlFetcher")
	private PdpUrlFetcher cachePdpUrlFetcher;
	@Autowired
    @Qualifier("inputDataPdpUrlFetcher")
    private PdpUrlFetcher inputDataPdpUrlFetcher;

	@PostConstruct
	public void initialiseFetcherChain() {
		this.setSuccessor(cachePdpUrlFetcher);
		cachePdpUrlFetcher.setSuccessor(inputDataPdpUrlFetcher);
		inputDataPdpUrlFetcher.setSuccessor(addressPdpUrlFetcher);
	}
	
	@Override
	protected String myGet(PdpUrlRequest pdpUrlRequest) {
	    return successor.get(pdpUrlRequest);
	}
}
