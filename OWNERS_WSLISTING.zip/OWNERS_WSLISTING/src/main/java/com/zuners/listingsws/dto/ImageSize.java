package com.zuners.listingsws.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Contains image size details.
 * 
 * @author patelpaw
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
public class ImageSize implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The target. */
    private String target;

    /** The target dimensions. */
    private String targetDimensions;

    /** The path. */
    private String path;

    /** The height. */
    private Integer height;

    /** The width. */
    private Integer width;

    /**
     * Gets the target.
     *
     * @return the target
     */
    public String getTarget() {
        return target;
    }

    /**
     * Sets the target.
     *
     * @param target
     *            the target to set
     */
    public void setTarget( String target ) {
        this.target = target;
    }

    /**
     * Gets the target dimensions.
     *
     * @return the targetDimensions
     */
    public String getTargetDimensions() {
        return targetDimensions;
    }

    /**
     * Sets the target dimensions.
     *
     * @param targetDimensions
     *            the targetDimensions to set
     */
    public void setTargetDimensions( String targetDimensions ) {
        this.targetDimensions = targetDimensions;
    }

    /**
     * Gets the path.
     *
     * @return the path
     */
    public String getPath() {
        return path;
    }

    /**
     * Sets the path.
     *
     * @param path
     *            the path to set
     */
    public void setPath( String path ) {
        this.path = path;
    }

    /**
     * Gets the height.
     *
     * @return the height
     */
    public Integer getHeight() {
        return height;
    }

    /**
     * Sets the height.
     *
     * @param height
     *            the height to set
     */
    public void setHeight( Integer height ) {
        this.height = height;
    }

    /**
     * Gets the width.
     *
     * @return the width
     */
    public Integer getWidth() {
        return width;
    }

    /**
     * Sets the width.
     *
     * @param width
     *            the width to set
     */
    public void setWidth( Integer width ) {
        this.width = width;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "ImageSize [target=" );
        builder.append( target );
        builder.append( ", targetDimensions=" );
        builder.append( targetDimensions );
        builder.append( ", path=" );
        builder.append( path );
        builder.append( ", height=" );
        builder.append( height );
        builder.append( ", width=" );
        builder.append( width );
        builder.append( "]" );
        return builder.toString();
    }

}
