/** RestClientServiceImpl.java*/
package com.zuners.listingsws.common;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hubzu.common.logger.HubzuLog;

/**
 * The rest client service implementation.
 * 
 * @author parakhsh
 * 
 */
@Service("restClientService")
public class RestClientService {
	
	private final static HubzuLog LOGGER = HubzuLog.getLogger(RestClientService.class);

    /** {@link RestTemplate} instance. */
    @Autowired
    private RestTemplate restTemplate;

    /**
     * @param url
     *            - the URL.
     * @param jsonValue
     *            - the jsonValue of Entity to be posted.
     * @param operationDetails
     *            - the operation details.
     */
    public void postEntity(final String url, final String jsonValue) {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        try {
            final HttpEntity<String> entity = new HttpEntity<String>(jsonValue, headers);
            restTemplate.postForLocation(url, entity);
        } catch (RestClientException rce) {
            if (rce instanceof HttpStatusCodeException) {
                String errorCause = ((HttpStatusCodeException) rce).getResponseBodyAsString();
                LOGGER.error("Error while serializing object, url : {}, jsonValue : {}, errorCause : {}", url,
                        jsonValue, errorCause);
            }
            throw rce;
        }
    }

    /**
     * Get the entity by type of object.
     * 
     * @param url
     *            - the URL for get entity.
     * @param clazz
     *            - the type of class for output.
     */
    public <E> Object getEntityByType(final String url, final Class<E> clazz) {
        E outputObject = restTemplate.getForObject(url, clazz);
        return outputObject;

    }

    public ResponseEntity<String> getEntity(URI uri, Class<String> clazz) {
        ResponseEntity<String> responseEntity = null;
        try {
            responseEntity = restTemplate.getForEntity(uri, clazz);
        } catch (RestClientException rce) {
            if (rce instanceof HttpStatusCodeException) {
                String errorCause = ((HttpStatusCodeException) rce).getResponseBodyAsString();
                LOGGER.error( "Error while serializing object, uri : {}, errorCause : {}", uri , errorCause );
            }
            throw rce;
        }
        return responseEntity;
    }

    public <T> T getForObject(String url, Class<T> responseType, Object... urlVariables) {
        T response = restTemplate.getForObject(url, responseType, urlVariables);
        return response;
    }
    
    public < E > E getJsonEntity( final String url, Class<E> clazz) {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType( MediaType.APPLICATION_JSON );
        try {
            final HttpEntity< String > entity = new HttpEntity< String >( headers );
            ResponseEntity< E > response = restTemplate.exchange( url, HttpMethod.GET, entity, clazz);
            return response.getBody();
        } catch ( RestClientException rce ) {
            if (rce instanceof HttpStatusCodeException) {
                String errorCause = ( ( HttpStatusCodeException ) rce ).getResponseBodyAsString();
                LOGGER.error( "Error while serializing object, url : {}, errorCause : {}", url , errorCause );
            }
            throw rce;
        }
    }
    
    public < T > T postEntity( String url, Object jsonObject, Class< T > clazz ) {
        ObjectMapper objectMapper = new ObjectMapper();
        String json;
        try {
            json = objectMapper.writeValueAsString( jsonObject );
            return postEntity( url, json, clazz );
        } catch ( JsonProcessingException e ) {
            LOGGER.error( "Error while serializing object : {}", jsonObject , e );
        }
        return null;
    }
    
    public < T > T postEntity( final String url, final String jsonValue, Class< T > clazz ) {
        LOGGER.debug( "Hitting post url : {} with json : {}", url, jsonValue );
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType( MediaType.APPLICATION_JSON );
        LOGGER.debug( "Posting entity :" + jsonValue + " to url" + url );
        try {
            final HttpEntity< String > entity = new HttpEntity< String >( jsonValue, headers );
            ResponseEntity< T > response = restTemplate.postForEntity( url, entity, clazz );
            return response.getBody();
        } catch ( RestClientException rce ) {
            LOGGER.error( "Got exception while posting entity to :" + url, rce );
            if (rce instanceof HttpStatusCodeException) {
                String errorCause = ( ( HttpStatusCodeException ) rce ).getResponseBodyAsString();
                LOGGER.error( "Error while hitting url :" + url + " errorCause :" + errorCause, rce );
            }
            throw rce;
        }
    }

	public <T> T getEntityWithGenericResponse(final String url, ParameterizedTypeReference<T> clazz) {
		LOGGER.debug("Hitting get url : {}", url);
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		try {
			final HttpEntity<String> entity = new HttpEntity<String>(headers);
			ResponseEntity<T> response = restTemplate.exchange(url, HttpMethod.GET, entity, clazz);
			return response.getBody();
		} catch (RestClientException rce) {
			LOGGER.error("Got exception while getting entity to :" + url, rce);
			if (rce instanceof HttpStatusCodeException) {
				String errorCause = ((HttpStatusCodeException) rce).getResponseBodyAsString();
				LOGGER.error("Error while hitting url :" + url + " errorCause :" + errorCause, rce);
			}
			throw rce;
		}
	}

    public < T > T postEntityWithGenericResponse( final String url, final String jsonValue, ParameterizedTypeReference< T > clazz ) {
        LOGGER.debug( "Hitting post url : {} with json : {}", url, jsonValue );
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType( MediaType.APPLICATION_JSON );
        LOGGER.debug( "Posting entity :" + jsonValue + " to url" + url );
        try {
            final HttpEntity< String > entity = new HttpEntity< String >( jsonValue, headers );
            ResponseEntity< T > response = restTemplate.exchange( url, HttpMethod.POST, entity, clazz );
            return response.getBody();
        } catch ( RestClientException rce ) {
            LOGGER.error( "Got exception while posting entity to :" + url, rce );
            if (rce instanceof HttpStatusCodeException) {
                String errorCause = ( ( HttpStatusCodeException ) rce ).getResponseBodyAsString();
                LOGGER.error( "Error while hitting url :" + url + " errorCause :" + errorCause, rce );
            }
            throw rce;
        }
    }
    
	public <T> T postEntityWithGenericResponse(String url, Object jsonObject, ParameterizedTypeReference<T> clazz) {
		ObjectMapper objectMapper = new ObjectMapper();
		String json;
		try {
			json = objectMapper.writeValueAsString(jsonObject);
			return postEntityWithGenericResponse(url, json, clazz);
		} catch (JsonProcessingException e) {
			LOGGER.error("Error while serializing object :" + jsonObject, e);
		}
		return null;
	}
}
