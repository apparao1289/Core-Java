package com.zuners.listingsws.common;

import static com.zuners.listingsws.common.Constants.MLS_PDP_RESPONSE_KEY;

import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hubzu.common.logger.HubzuLog;

public class JsonUtil {

    private final static HubzuLog logger = HubzuLog.getLogger(JsonUtil.class);

    public static final String RESP_STATUS = "responseStatus";
    public static final String METADATA = "metaData";
    public static final String RESULT = "result";
    public static final String TEXT = "text";

    /**
     * Gets actual object from json, after removing metadata
     * 
     * @param jsonData
     * @param clazz
     * @return
     * @throws ApplicationException
     */
    public static String getResponseFromJson(String jsonData) {
        logger.debug("Extracting actual response from json : {}", jsonData);
        if (!StringUtils.isEmpty(jsonData)) {
            JsonParser jsonParser = new JsonParser();
            JsonObject responseObject = null;
            JsonObject metaData = null;

            JsonElement element = jsonParser.parse(jsonData);
            if (element.isJsonObject()) {
                responseObject = element.getAsJsonObject();
                if (responseObject.isJsonObject() && responseObject.get(METADATA).isJsonObject()) {
                    metaData = responseObject.getAsJsonObject(METADATA);
                }
            }

            if (metaData != null && metaData.isJsonObject()
                    && !metaData.get(RESP_STATUS).isJsonNull()) {
                JsonElement result = null;
                if (responseObject != null)
                    result = responseObject.get(RESULT);
                if (result != null && !result.isJsonNull()) {
                    String json = result.toString();
                    return json;
                }
            }
        }
        return null;
    }

    public static <T> T convertFromJson(String object, Class<T> valueType)
            throws JsonParseException, JsonMappingException, IOException {
        if (!StringUtils.isEmpty(object)) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            return mapper.readValue(object, valueType);
        } else {
            return null;
        }
    }

    public static String copyElement(String from, String to, String elementKey, String parentElement) {
        JSONObject fromJsonObject = new JSONObject(from);
        JSONObject toJsonObject = new JSONObject(to);
        JSONArray fromDataArray = fromJsonObject.getJSONArray(parentElement);
        JSONArray toDataArray = toJsonObject.getJSONArray(parentElement);
        for (int i = 0; i < fromDataArray.length(); i++) {
            JSONObject curJsonObject = (JSONObject) fromDataArray.get(i);
            String curJsonString = curJsonObject.optString(MLS_PDP_RESPONSE_KEY);
            if (curJsonString.equals(elementKey)) {
                toDataArray.put(curJsonObject);
            }
        }
        return toJsonObject.toString();
    }
    
    public static String replaceElement(String from, String to, String elementKey) {
        JSONObject fromJsonObject = new JSONObject(from);
        JSONObject toJsonObject = new JSONObject(to);
        JSONArray fromDataArray = fromJsonObject.getJSONArray(elementKey);
        toJsonObject.put(elementKey, fromDataArray);
        return toJsonObject.toString();
    }

    public static String addElement(String from, String to, String element) {
        JSONObject fromJsonObject = new JSONObject(from);
        JSONArray dataArray = fromJsonObject.getJSONArray(element);

        JSONObject toObject = new JSONObject(to);
        toObject.put(element, dataArray);
        return toObject.toString();
    }
}
