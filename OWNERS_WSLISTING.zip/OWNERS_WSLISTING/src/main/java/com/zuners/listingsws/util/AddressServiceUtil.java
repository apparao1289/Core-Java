package com.zuners.listingsws.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.hubzu.search.common.enums.ErrorCode;
import com.hubzu.search.common.exception.ApplicationException;
import com.hubzu.search.model.property.PropertyAddress;
import com.zuner.addrserv.model.common.Address;
import com.zuner.addrserv.model.common.GeoCode;
import com.zuner.addrserv.model.common.Pagination;
import com.zuner.addrserv.model.common.PolygonDataSubset;
import com.zuner.addrserv.model.common.PolygonDetailedInfo;
import com.zuner.addrserv.model.enums.DataKey;
import com.zuner.addrserv.model.request.AddressRequest;
import com.zuner.addrserv.model.response.AddressDataResponse;
import com.zuner.addrserv.model.response.GeoTagResponse;
import com.zuner.addrserv.model.response.Response;
import com.zuners.listingsws.common.RestClientService;

@Service
public class AddressServiceUtil {

	private static final String URL_SEPARATOR = "/";
	private static final String URL_QUERY_SEPARATOR = "?";
	private static final String QUERY_SEPARATOR = "&";
	private static final String EQUAL_TO = "=";

	@Autowired
	private RestClientService restClientService;

	@Value("${listingws.address_service_url}")
	public String addressServiceUrl;

	public GeoTagResponse getGeotagDetails(GeoCode geoCode, String state) {
		String url = addressServiceUrl + URL_SEPARATOR + "api" + URL_SEPARATOR + "geotag" + URL_SEPARATOR + state;
		try {
			Response<GeoTagResponse> geoTagResponse = restClientService.postEntityWithGenericResponse(url, geoCode,
					new ParameterizedTypeReference<Response<GeoTagResponse>>() {
					});
			if (geoTagResponse != null) {
				return geoTagResponse.getResult();
			}
		} catch (RestClientException e) {
			throw new ApplicationException(e.getMessage(), ErrorCode.ADDRESS_SERVICE_UNREACHABLE);
		}
		return null;
	}

	public AddressDataResponse getGeocodeDetails(PropertyAddress propertyAddress) {
		List<DataKey> dataKeys = new ArrayList<>();
		dataKeys.add(DataKey.GEOCODE);
		dataKeys.add(DataKey.GEOTAG);
		return getAddressDetails(propertyAddress, dataKeys);
	}

	public AddressDataResponse getAddressDetailsById(String id, List<DataKey> dataKeys) {
		String url = addressServiceUrl + URL_SEPARATOR + "api" + URL_SEPARATOR + "address_details" + URL_SEPARATOR + id
				+ URL_QUERY_SEPARATOR + "dataKeys" + EQUAL_TO
				+ dataKeys.stream().map(e -> e.toString()).collect(Collectors.joining(","));
		try {
			Response<AddressDataResponse> addressServiceResponse = restClientService.getEntityWithGenericResponse(url,
					new ParameterizedTypeReference<Response<AddressDataResponse>>() {
					});
			if (addressServiceResponse != null) {
				return addressServiceResponse.getResult();
			}
		} catch (RestClientException e) {
			throw new ApplicationException(e.getMessage(), ErrorCode.ADDRESS_SERVICE_UNREACHABLE);
		}
		return null;
	}

	public AddressDataResponse getAddressDetails(Address address, List<DataKey> dataKeys) {
		AddressRequest addressRequest = new AddressRequest();
		addressRequest.setAddress(address);
		addressRequest.setDataKeys(dataKeys);
		addressRequest.setClientId("OWNERS_WSLISTING");
		String url = addressServiceUrl + URL_SEPARATOR + "api" + URL_SEPARATOR + "address_details";
		try {
			Response<AddressDataResponse> addressServiceResponse = restClientService.postEntityWithGenericResponse(url,
					addressRequest, new ParameterizedTypeReference<Response<AddressDataResponse>>() {
					});
			if (addressServiceResponse != null) {
				return addressServiceResponse.getResult();
			}
		} catch (RestClientException e) {
			throw new ApplicationException(e.getMessage(), ErrorCode.ADDRESS_SERVICE_UNREACHABLE);
		}
		return null;
	}

	public AddressDataResponse getAddressDetails(PropertyAddress propertyAddress, List<DataKey> dataKeys) {
		Address address = new Address();
		address.setCity(propertyAddress.getCity());
		address.setState(propertyAddress.getState());
		address.setZip(propertyAddress.getZip());
		address.setStreetName(propertyAddress.getStreetName());
		address.setStreetNumber(propertyAddress.getStreetNumber());
		return getAddressDetails(address, dataKeys);
	}

	public PolygonDetailedInfo getPolygonDetails(BigInteger polygonId) {
		String url = addressServiceUrl + URL_SEPARATOR + "api" + URL_SEPARATOR + "polygon" + URL_SEPARATOR + polygonId;
		try {
			Response<PolygonDetailedInfo> addressServiceResponse = restClientService.getEntityWithGenericResponse(url,
					new ParameterizedTypeReference<Response<PolygonDetailedInfo>>() {
					});
			if (addressServiceResponse != null) {
				return addressServiceResponse.getResult();
			}
		} catch (RestClientException e) {
			throw new ApplicationException(e.getMessage(), ErrorCode.ADDRESS_SERVICE_UNREACHABLE);
		}
		return null;
	}

	public PolygonDetailedInfo getPolygonDetailsFromId(String polygonId) {
		String url = addressServiceUrl + URL_SEPARATOR + "api" + URL_SEPARATOR + "polygonid" + URL_SEPARATOR
				+ polygonId;
		try {
			Response<PolygonDetailedInfo> addressServiceResponse = restClientService.getEntityWithGenericResponse(url,
					new ParameterizedTypeReference<Response<PolygonDetailedInfo>>() {
					});
			if (addressServiceResponse != null) {
				return addressServiceResponse.getResult();
			}
		} catch (RestClientException e) {
			throw new ApplicationException(e.getMessage(), ErrorCode.ADDRESS_SERVICE_UNREACHABLE);
		}
		return null;
	}

	public List<PolygonDataSubset> getPolygonDetailsPageWise(int pageNumber, int pageSize,
			List<String> ignoreCategory) {
		String url = addressServiceUrl + URL_SEPARATOR + "api" + URL_SEPARATOR + "get_polygons" + URL_QUERY_SEPARATOR
				+ "pageNumber" + EQUAL_TO + pageNumber + QUERY_SEPARATOR + "pageSize" + EQUAL_TO + pageSize
				+ getListParameters("ignorePolygonTypes", ignoreCategory);
		try {
			Response<Pagination<PolygonDataSubset>> addressServiceResponse = restClientService
					.getEntityWithGenericResponse(url,
							new ParameterizedTypeReference<Response<Pagination<PolygonDataSubset>>>() {
							});
			if (addressServiceResponse != null && addressServiceResponse.getResult() != null) {
				return addressServiceResponse.getResult().getContent();
			}
		} catch (RestClientException e) {
			throw new ApplicationException(e.getMessage(), ErrorCode.ADDRESS_SERVICE_UNREACHABLE);
		}
		return null;
	}

	private String getListParameters(String requestParamKey, List<String> requestParamValue) {
		StringBuilder requestParameter = new StringBuilder();
		for (String paramValue : requestParamValue) {
			requestParameter.append(QUERY_SEPARATOR + requestParamKey + EQUAL_TO);
			requestParameter.append(paramValue);
		}
		return requestParameter.toString();
	}

}
