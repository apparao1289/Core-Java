package com.zuners.listingsws.request;

public class ListingRequest {

    String id;
    String cohort;
    String userId;
    private String version;

    public String getId() {
        return id;
    }

    public void setId( String id ) {
        this.id = id;
    }

    public String getCohort() {
        return cohort;
    }

    public void setCohort( String cohort ) {
        this.cohort = cohort;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId( String userId ) {
        this.userId = userId;
    }
    
    public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "ListingRequest [id=" );
        builder.append( id );
        builder.append( ", cohort=" );
        builder.append( cohort );
        builder.append( ", userId=" );
        builder.append( userId );
        builder.append( ", version=" );
        builder.append( version );
        builder.append( "]" );
        return builder.toString();
    }
    
}
