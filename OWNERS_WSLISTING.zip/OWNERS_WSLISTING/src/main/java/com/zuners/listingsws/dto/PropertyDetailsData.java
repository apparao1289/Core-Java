package com.zuners.listingsws.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Contains data sets of the property
 * 
 * @author patelpaw
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
public class PropertyDetailsData implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The key. */
    private String key;

    /** The type. */
    private String type;

    /** The photos. */
    private List< PhotoDetails > photos;

    /** The data. */
    private List< PropertyData > data;

    /**
     * Gets the key.
     *
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the key.
     *
     * @param key
     *            the key to set
     */
    public void setKey( String key ) {
        this.key = key;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the type to set
     */
    public void setType( String type ) {
        this.type = type;
    }

    /**
     * Gets the photos.
     *
     * @return the photos
     */
    public List< PhotoDetails > getPhotos() {
        return photos;
    }

    /**
     * Sets the photos.
     *
     * @param photos
     *            the photos to set
     */
    public void setPhotos( List< PhotoDetails > photos ) {
        this.photos = photos;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public List< PropertyData > getData() {
        return data;
    }

    /**
     * Sets the data.
     *
     * @param data
     *            the data to set
     */
    public void setData( List< PropertyData > data ) {
        this.data = data;
    }
    
    public Map< String, List< String >> getDataMap() {
        Map< String, List< String >> mapData = null;
        if (!CollectionUtils.isEmpty( data )) {
            mapData = new HashMap< String, List< String >>();
            for ( PropertyData propertyData : data ) {
                mapData.put( propertyData.getKey(), propertyData.getValues() );
            }
        }
        return mapData;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append( "PropertyDetailsData [key=" );
        builder.append( key );
        builder.append( ", type=" );
        builder.append( type );
        builder.append( ", photos=" );
        builder.append( photos );
        builder.append( ", data=" );
        builder.append( data );
        builder.append( "]" );
        return builder.toString();
    }

}
