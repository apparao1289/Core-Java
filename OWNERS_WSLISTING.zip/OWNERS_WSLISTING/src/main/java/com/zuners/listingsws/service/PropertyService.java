package com.zuners.listingsws.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hubzu.search.model.property.PropertyAndListingDetails;

/**
 * The Class PropertyService.
 * 
 * @author rajputbh
 */
@Service
public interface PropertyService {
	public void add(PropertyAndListingDetails propertyAndListingDetails);

	public void delete(String propertyId);

	public PropertyAndListingDetails get(String propertyId);

	public List<PropertyAndListingDetails> get(String[] propertyIdList);
}
