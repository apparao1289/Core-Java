package com.zuners.listingsws.pdp.url;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.hubzu.common.logger.HubzuLog;
import com.zuner.addrserv.model.response.NormalisedAddress;
import com.zuners.listingsws.request.PdpUrlRequest;
import com.zuners.listingsws.service.PdpUrlService;

/**
 * The class InputDataPdpUrlFetcher
 *
 * @author dlp
 *
 */
@Service("inputDataPdpUrlFetcher")
public class InputDataPdpUrlFetcher extends PdpUrlFetcher {

    private final static HubzuLog LOGGER = HubzuLog.getLogger(InputDataPdpUrlFetcher.class);
    @Autowired
    private PdpUrlService pdpUrlService;

    @Override
    protected String myGet(PdpUrlRequest pdpUrlRequest) {
        if (isMandatoryFieldsPresent(pdpUrlRequest)) {
            return pdpUrlService.getPdpAddressString(prepareNormalisedAddress(pdpUrlRequest));
        } else {
            LOGGER.info("mandatory fields are not present. calling successor fetcher");
            return successor != null ? successor.get(pdpUrlRequest) : null;
        }
    }

    private NormalisedAddress prepareNormalisedAddress(PdpUrlRequest pdpUrlRequest) {
        if (pdpUrlRequest == null) {
            return null;
        }

        NormalisedAddress normalisedAddress = new NormalisedAddress();
        normalisedAddress.setAddressHash(pdpUrlRequest.getAddressHash());
        normalisedAddress.setStreetName(pdpUrlRequest.getStreetName());
        normalisedAddress.setStreetNumber(pdpUrlRequest.getStreetNumber());
        normalisedAddress.setStreetSuffix(pdpUrlRequest.getStreetSuffix());
        normalisedAddress.setSuiteName(pdpUrlRequest.getSuiteName());
        normalisedAddress.setSuiteNumber(pdpUrlRequest.getSuiteNumber());
        normalisedAddress.setZip(pdpUrlRequest.getZip());
        return normalisedAddress;
    }

    private boolean isMandatoryFieldsPresent(PdpUrlRequest pdpUrlRequest) {
        if (pdpUrlRequest != null && StringUtils.hasText(pdpUrlRequest.getStreetName())
                && StringUtils.hasText(pdpUrlRequest.getZip()) && StringUtils.hasText(pdpUrlRequest.getCity())) {
            return true;
        }
        return false;
    }
}
